package com.example.edurise

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
