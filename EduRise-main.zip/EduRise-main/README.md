# EduRise

A Platfrom for connecting Students with Tuitions


