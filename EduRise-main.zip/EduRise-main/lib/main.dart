import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:edurise/Provider/auth.dart';
import 'package:edurise/Provider/students.dart';
import 'package:edurise/Provider/tuitions.dart';
import 'package:edurise/Views/Additional/landing_page.dart';
import 'package:edurise/Views/Additional/onboardingScreens/welcome_page.dart';
import 'package:edurise/Views/Additional/splash_screen.dart';
import 'package:edurise/Views/Student/screens/search_tuition_page_for_students.dart';
import 'package:edurise/Views/Tuition/TuitionRegistration/tuition_otpscreen.dart';
import 'package:edurise/Views/Tuition/Screens/tuition_dashboard.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'Views/Additional/onboardingScreens/welcome_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  SystemChrome.setEnabledSystemUIOverlays(
      [SystemUiOverlay.bottom, SystemUiOverlay.top]);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {



  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: Init.instance.initialize(context),
      builder: (context, AsyncSnapshot snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return MaterialApp(home: SplashScreen());
        } else {
          return MultiProvider(
            providers: [
              ChangeNotifierProvider<Tuitions>(
                create: (_) => Tuitions(),
              ),
              ChangeNotifierProvider<Auth>(
                create: (_) => Auth(),
              ),
              ChangeNotifierProvider<Students>(
                create: (_) => Students(),
              ),
            ],
            child: MaterialApp(
              debugShowCheckedModeBanner: false,
              title: 'EduRise',
              theme: ThemeData(
                primaryColor: Colors.red,
              ),
              home: getHome(snapshot.data),
              routes: {
                TuitionOtpScreen.routeName: (ctx) => TuitionOtpScreen(),
              },
            ),
          );
        }
      },
    );
  }

  Widget getHome(int authLevel) {
    switch (authLevel) {
      case -1:
        return Welcomepage();
      // break;
      case 0:
        return LandingPage();
      // break;
      case 1:
        return TuitionDashBoard();
      // break;
      case 2:
        return StudentTuitionSearchPage();
      // break;
      default:
        return Center(child: Text('Something Went wrong : ((((('));
    }
  }
}

class Init {
  Init._();
  static final instance = Init._();

  Future<int?> initialize(BuildContext context) async {
    await Firebase.initializeApp();
    if (!Auth.isAuth) {
      int x = await checkFirstSeen();
      // print(x);
      if (x == 1) {
        return 0;
      } else
        return -1;
    } else {
      Auth.setUid();
      var tuitiondocumentSnapshot = await FirebaseFirestore.instance
          .collection('Tuition')
          .doc(Auth.uid)
          .get();
      var studentdocumentSnapshot = await FirebaseFirestore.instance
          .collection('Student')
          .doc(Auth.uid)
          .get();

      if (tuitiondocumentSnapshot.exists) {
        return 1;
      } else if (studentdocumentSnapshot.exists) {
        return 2;
      } else {
        return 0;
      }
    }
  }

  Future<int> checkFirstSeen() async {
    // SharedPreferences.setMockInitialValues({});
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool _seen = (prefs.getBool('seen') ?? false);
    if (_seen) {
      return 1;
    } else {
      await prefs.setBool('seen', true);
      return -1;
    }
  }
}




