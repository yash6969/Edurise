import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:edurise/Models/tuition.dart';
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;

class Tuitions with ChangeNotifier {
  List<Tuition> tuitions = [];
  List<Tuition> tuitionsWithPincode = [];

  Tuition getTuition(String index) {
    return tuitions.firstWhere((e) => e.uid == index);
  }

  Future<void> fetchAndSetTuitions() async {
    CollectionReference _collectionRef =
        FirebaseFirestore.instance.collection('Tuition');
    QuerySnapshot allDataQuerySnapshot = await _collectionRef.get();
    tuitions = allDataQuerySnapshot.docs
        .map((doc) => doc.data())
        .toList()
        .map((e) => Tuition.fromMap(e as Map<String, dynamic>))
        .toList();
    notifyListeners();
  }

  Future<void> fetchAndSetTuitionswithPincode(String pincode) async {
    CollectionReference _collectionRef =
        FirebaseFirestore.instance.collection('Tuition');
    QuerySnapshot allDataQuerySnapshot = await _collectionRef
        .where('pincode', isEqualTo: pincode.toString())
        .get();
    tuitionsWithPincode = allDataQuerySnapshot.docs
        .map((doc) => doc.data())
        .toList()
        .map((e) => Tuition.fromMap(e as Map<String, dynamic>))
        .toList();
    notifyListeners();
  }

  Future<void> updateTuition(Tuition t) async {
    CollectionReference tuitions =
        FirebaseFirestore.instance.collection('Tuition');
    await tuitions.doc(t.uid).update(t.toMap()).then((_) {});
    await fetchAndSetTuitions();
    notifyListeners();
  }

  Future<void> addTuition(Tuition t) async {
    CollectionReference tuitions =
        FirebaseFirestore.instance.collection('Tuition');
    String uid = t.uid;
    await tuitions.doc(uid).set(t.toMap());
    await fetchAndSetTuitions();
    notifyListeners();
    return;
  }

  Future<String> getImageUrl(String id) async {
    String imageUrl = await firebase_storage.FirebaseStorage.instance
        .ref('TuitionImages/$id')
        .getDownloadURL();
    return imageUrl;
  }
}
