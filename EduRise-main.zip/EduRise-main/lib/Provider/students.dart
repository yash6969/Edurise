import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:edurise/Models/student.dart';
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;

class Students with ChangeNotifier {
  List<Student> students = [];

  Student getStudent(String index) {
    fetchAndSetStudents();
    return students.firstWhere((e) => e.uid == index);
  }

  Future<void> fetchAndSetStudents() async {
    CollectionReference _collectionRef =
        FirebaseFirestore.instance.collection('Student');
    QuerySnapshot allDataQuerySnapshot = await _collectionRef.get();
    students = allDataQuerySnapshot.docs
        .map((doc) => doc.data())
        .toList()
        .map((e) => Student.fromMap(e as Map<String, dynamic>))
        .toList();
    notifyListeners();
  }

  Future<void> updateStudent(Student t) async {
    CollectionReference students =
        FirebaseFirestore.instance.collection('Student');
    await students.doc(t.uid).update(t.toMap()).then((_) {});
    await fetchAndSetStudents();
    notifyListeners();
  }

  Future<void> addStudent(Student t) async {
    CollectionReference students =
        FirebaseFirestore.instance.collection('Student');
    String uid = t.uid;
    await students.doc(uid).set(t.toMap());
    await fetchAndSetStudents();
    notifyListeners();
    return;
  }

  Future<String> getImageUrl(String id) async {
    String imageUrl = await firebase_storage.FirebaseStorage.instance
        .ref('StudentImages/$id')
        .getDownloadURL();
    return imageUrl;
  }
}
