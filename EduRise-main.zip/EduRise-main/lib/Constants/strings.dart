class Strings {
  static final appTitle = 'Edurise';
  static final welcomeText = 'Welcome to Edurise';
  static final tagline = 'Connecting Student with Tuitions';

  // Onbaording Screens
  static var stepOneTitle = "Looking for Tuitions";
  static var stepOneContent = "Get Information about Tuitions in your area";
  static var stepTwoTitle = "Teach Someone ";
  static var stepTwoContent = "Get Students for starting your Teaching";
  static var stepThreeTitle = "Grow your Tuition";
  static var stepThreeContent =
      "Make Students know your achievements and grow up your Tuition";
}
