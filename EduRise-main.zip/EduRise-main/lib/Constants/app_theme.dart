import 'package:flutter/material.dart';

class CustomColors {
  static final Color arcadiaPrimaryColor = Color(0xFF2C384A);
  static final Color arcadiaSecondaryColor = Color(0xFF262A34);
  static final Color toyoPrimaryColor = Color(0xFF403b58);

  static final Color primaryColor = Color(0xFFF96559);
  static final Color secondaryColor = Color(0xFFFFDEDE);
  static final Color buttonColor = Color(0xFFF96559);
  static final Color textColor = Color(0xFFF96559);
  static final Color boxColourWithOpacity = Color(0xFFF96559).withOpacity(0.7);

  static Color onboardingPrimary = Color.fromRGBO(52, 43, 37, 1);
  static Color onboardinggray = Color.fromRGBO(137, 137, 137, 1);
  static Color onboardingsecoundry = Color.fromRGBO(198, 116, 27, 1);
  static Color onboardingsecoundryLight = Color.fromRGBO(226, 185, 141, 1);
}
