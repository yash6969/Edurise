import 'package:edurise/Constants/app_theme.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ReviewCard extends StatelessWidget {
  final Map<String, String> review;

  ReviewCard(this.review);

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return Container(
      width: width,
      height: height / 7,
      padding: new EdgeInsets.all(10.0),
      child: Card(
        shape: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(20))),
        color: CustomColors.boxColourWithOpacity,
        margin: EdgeInsets.only(left: 0, right: 0, top: 0, bottom: 0),
        child: Center(
          child: ListTile(
            isThreeLine: false,
            // horizontalTitleGap: 2,
            minLeadingWidth: width / 8,
            title: Text(
              review.keys.toString(),
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(review.values.toString(),
                  style: TextStyle(fontWeight: FontWeight.w500)),
            ),
          ),
        ),
      ),
    );
  }
}
