import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Views/Additional/landing_page.dart';
import 'package:flutter/material.dart';

class OnboardingThird extends StatefulWidget {
  OnboardingThird({key}) : super(key: key);

  @override
  _OnboardingThirdState createState() => _OnboardingThirdState();
}

class _OnboardingThirdState extends State<OnboardingThird> {
  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: CustomColors.boxColourWithOpacity,
      body: Column(
        // mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          SizedBox(height: height / 7),
          Container(
              alignment: Alignment.center,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // SizedBox(height: 20),
                    Text("Grow your Tuition",
                        style: const TextStyle(
                            color: const Color(0xfffaf5f0),
                            fontWeight: FontWeight.w900,
                            fontFamily: "Graphik",
                            fontStyle: FontStyle.normal,
                            fontSize: 33.8),
                        textAlign: TextAlign.center),

                    SizedBox(height: height / 10),

                    Center(
                        child: Image(
                      image: AssetImage('assets/images/institute.png'),
                      width: 250,
                    )),
                    SizedBox(height: height / 10),
                    Text(
                        "Make Students know your \nachievements and grow up your Tuition",
                        style: const TextStyle(
                            color: const Color(0xfffaf5f0),
                            // fontWeight: FontWeight.w700,
                            fontFamily: "Graphik",
                            fontStyle: FontStyle.normal,
                            fontSize: 16),
                        textAlign: TextAlign.center),
                    SizedBox(height: height / 20),
                    Container(
                        height: 50.0,
                        margin: EdgeInsets.all(30),
                        child: RaisedButton(
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => LandingPage()));
                            },
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(80.0)),
                            padding: EdgeInsets.all(0.0),
                            child: Ink(
                                decoration: BoxDecoration(
                                    color: CustomColors.boxColourWithOpacity,
                                    borderRadius: BorderRadius.circular(30.0)),
                                child: Container(
                                  alignment: Alignment.center,
                                  child: new Text("Lets Go ! ",
                                      style: TextStyle(
                                        fontFamily: 'Graphik',
                                        color: Colors.white,
                                        fontSize: 17,
                                        fontWeight: FontWeight.w500,
                                        fontStyle: FontStyle.normal,
                                        letterSpacing: -0.417,
                                      )),
                                ))))
                  ])),
        ],
      ),
    );
  }
}
