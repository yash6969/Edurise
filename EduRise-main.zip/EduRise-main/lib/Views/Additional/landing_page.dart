import 'package:edurise/Views/Guest/screens/search_tuition_page.dart';
import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Constants/strings.dart';
import 'package:edurise/Views/Student/StudentRegistration/student_login.dart';
import 'package:edurise/Views/Tuition/TuitionRegistration/tuition_login.dart';
import 'package:flutter/material.dart';

class LandingPage extends StatefulWidget {
  @override
  _LandingPageState createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return Material(
      color: CustomColors.secondaryColor,
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              SizedBox(
                height: height / 10,
              ),
              Image.asset(
                "assets/images/logo_transparent.png",
                height: height / 4,
                width: width / 2,
              ),
              Text(
                Strings.tagline,
                style: TextStyle(
                  fontSize: height / 48,
                  fontWeight: FontWeight.bold,
                  color: CustomColors.textColor,
                ),
              ),
              SizedBox(
                height: height / 10,
              ),
              InkWell(
                onTap: () => {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => StudentLoginPage()))
                },
                child: AnimatedContainer(
                  duration: Duration(seconds: 1),
                  width: width / 1.4,
                  height: height / 14,
                  alignment: Alignment.center,
                  child: Text(
                    "Enter as Student",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: height / 45,
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: CustomColors.buttonColor,
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              SizedBox(
                height: height / 17,
              ),
              InkWell(
                onTap: () => {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => TuitionLoginPage()))
                },
                child: AnimatedContainer(
                  duration: Duration(seconds: 1),
                  width: width / 1.4,
                  height: height / 14,
                  alignment: Alignment.center,
                  child: Text(
                    "Enter as Tuition",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: height / 45,
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: CustomColors.buttonColor,
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              SizedBox(
                height: height / 17,
              ),
              InkWell(
                onTap: () => {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => SearchTuitionPage()),
                  ),
                },
                child: AnimatedContainer(
                  duration: Duration(seconds: 1),
                  width: width / 1.4,
                  height: height / 14,
                  alignment: Alignment.center,
                  child: Text(
                    "Enter as Guest",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: height / 45,
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: CustomColors.buttonColor,
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              SizedBox(
                height: height / 12,
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Terms of use",
                    style: TextStyle(
                      color: CustomColors.toyoPrimaryColor,
                      fontWeight: FontWeight.bold,
                      fontSize: height / 52,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  SizedBox(
                    width: width / 15,
                  ),
                  Text(
                    "Privacy Policy",
                    style: TextStyle(
                      color: CustomColors.toyoPrimaryColor,
                      fontWeight: FontWeight.bold,
                      fontSize: height / 52,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
