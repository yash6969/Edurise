import 'package:flutter/material.dart';

class LoadingScreen extends StatelessWidget {
  const LoadingScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            //  Text("Wait for a while")
            Container(
              color: Colors.white,
              height: height / 5,
              width: width / 3,
              child: Image.asset(
                'assets/images/logoanimation.gif',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
