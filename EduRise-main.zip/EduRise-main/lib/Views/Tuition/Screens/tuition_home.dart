import 'package:cached_network_image/cached_network_image.dart';
import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Models/tuition.dart';
import 'package:edurise/Provider/students.dart';
import 'package:edurise/Provider/tuitions.dart';
import 'package:edurise/Views/Additional/loading_screen.dart';
import 'package:edurise/Views/Tuition/Screens/tuition_reviews_page.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'update_profile.dart';

class TuitionHome extends StatefulWidget {
  final Tuition? currTuition;
  TuitionHome(this.currTuition);
  @override
  State<TuitionHome> createState() => _TuitionHomeState();
}

class _TuitionHomeState extends State<TuitionHome> {
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return SingleChildScrollView(
        child: isLoading
            ? LoadingScreen()
            : Container(
                color: CustomColors.secondaryColor,
                height: height,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: height / 15,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: width * 0.00001,
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 50),
                            child: Container(
                                child: Text(
                              widget.currTuition!.tuitionName,
                              style: TextStyle(
                                  fontSize: 22, color: CustomColors.textColor),
                            )),
                          ),
                          FutureBuilder(
                                future: Provider.of<Tuitions>(context,
                                        listen: false)
                                    .getImageUrl(widget.currTuition!.uid.toString()),
                                builder: (context, snapshot) {
                                  if (snapshot.hasData) {
                                    return IconButton(
                                      icon: CircleAvatar(
                                        // minRadius: width / 8,
                                        // maxRadius: width / 8,
                                        minRadius: width / 24,
                                        maxRadius: width / 24,
                                        backgroundColor:
                                            CustomColors.boxColourWithOpacity,
                                        foregroundColor:
                                            CustomColors.boxColourWithOpacity,
                                        backgroundImage:
                                            CachedNetworkImageProvider(
                                          snapshot.data.toString(),
                                        ),
                                      ),
                                      onPressed: () => {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    UpdateProfile(widget.currTuition),),),
                                      },
                                    );
                                  } else if (snapshot.hasError) {
                                    return Icon(
                                        Icons.image_not_supported_sharp);
                                  } else {
                                    return CircleAvatar(
                                      radius: width / 15,
                                      backgroundColor:
                                          CustomColors.boxColourWithOpacity,
                                      foregroundColor:
                                          CustomColors.boxColourWithOpacity,
                                      // child: CircularProgressIndicator(),
                                    );
                                  }
                                },
                              ),
                        ],
                      ),
                    ),
                    SizedBox(height: height / 50),
                    Expanded(
                        child: Column(
                      children: <Widget>[
                        SizedBox(
                          height: 10,
                        ),
                        Expanded(
                            flex: 2,
                            child: Row(
                              children: <Widget>[
                                Expanded(
                                  child: new TuitionHomeCard(
                                    colour: CustomColors.boxColourWithOpacity,
                                    cardChild: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        SizedBox(
                                          height: 5,
                                        ),

                                        // Image.asset("assets/oxygen.png",height: 45,),
                                        Text(
                                          "Reach",
                                          style: TextStyle(
                                              fontSize: 18.0,
                                              fontWeight: FontWeight.normal),
                                        ),
                                        Text(
                                          widget.currTuition!.reach.toString(),
                                          style: TextStyle(
                                              fontSize: 40.0,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: new TuitionHomeCard(
                                    colour: CustomColors.boxColourWithOpacity,
                                    cardChild: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          "Views",
                                          style: TextStyle(
                                              fontSize: 18.0,
                                              fontWeight: FontWeight.normal),
                                        ),
                                        Text(
                                          widget.currTuition!.views.toString(),
                                          style: TextStyle(
                                              fontSize: 40.0,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            )),
                        Expanded(
                            flex: 2,
                            child: Row(
                              children: <Widget>[
                                Expanded(
                                  child: InkWell(
                                    onTap: () {
                                      // Navigator.push(
                                      //     context,
                                      //     MaterialPageRoute(
                                      //         builder: (context) =>
                                      //             TuitionReviewsPage(
                                      //                 widget.currTuition!)));
                                    },
                                    child: new TuitionHomeCard(
                                      colour: CustomColors.boxColourWithOpacity,
                                      cardChild: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Text(
                                            "Reviews",
                                            style: TextStyle(
                                                fontSize: 18.0,
                                                fontWeight: FontWeight.normal),
                                          ),
                                          Text(
                                            widget.currTuition!.reviews!.length
                                                .toString(),
                                            style: TextStyle(
                                                fontSize: 40.0,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: new TuitionHomeCard(
                                    colour: CustomColors.boxColourWithOpacity,
                                    cardChild: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          "Likes",
                                          style: TextStyle(
                                              fontSize: 18.0,
                                              fontWeight: FontWeight.normal),
                                        ),
                                        Text(
                                          "--",
                                          style: TextStyle(
                                              fontSize: 40.0,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            )),
                        Expanded(
                          flex: 2,
                          child: Container(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Align(
                                  alignment: Alignment(0, 0.0),
                                  child: Column(
                                    children: <Widget>[
                                      Text(
                                        "Students Enrolled",
                                        style: TextStyle(
                                            fontSize: 18.0,
                                            fontWeight: FontWeight.normal),
                                      ),
                                      Text(
                                        "00",
                                        style: TextStyle(
                                            fontSize: 40.0,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            margin: EdgeInsets.only(
                              left: 10.0,
                              right: 10.0,
                              top: 0.0,
                              bottom: 9.0,
                            ),
                            decoration: BoxDecoration(
                              color: CustomColors.boxColourWithOpacity,
                              borderRadius: BorderRadius.circular(4.0),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.5),
                                  spreadRadius: 2,
                                  blurRadius: 2,
                                  offset: Offset(0, 4),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    )),
                  ],
                )));
  }
}

class TuitionHomeCard extends StatelessWidget {
  TuitionHomeCard({required this.colour, required this.cardChild});

  final Color colour;
  final Widget cardChild;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: cardChild,
      margin: EdgeInsets.only(
        left: 10.0,
        right: 10.0,
        top: 0.0,
        bottom: 9.0,
      ),
      decoration: BoxDecoration(
        color: colour,
        borderRadius: BorderRadius.circular(4.0),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 2,
            blurRadius: 2,
            offset: Offset(0, 4), // changes position of shadow
          ),
        ],
      ),
    );
  }
}
