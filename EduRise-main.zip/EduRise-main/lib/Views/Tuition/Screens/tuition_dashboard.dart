import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Models/tuition.dart';
import 'package:edurise/Provider/auth.dart';
import 'package:edurise/Provider/tuitions.dart';
import 'package:edurise/Views/Additional/loading_screen.dart';
import 'package:edurise/Views/Tuition/Screens/tuition_home.dart';
import 'package:edurise/Views/Tuition/Screens/tuition_reviews_page.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'tution_map.dart';
import 'update_profile.dart';

class TuitionDashBoard extends StatefulWidget {
  static const routeName = '/Tuition-dashBoard';

  @override
  State<TuitionDashBoard> createState() => _TuitionDashBoardState();
}

class _TuitionDashBoardState extends State<TuitionDashBoard> {
  static Tuition? currTuition;
  String? uid;

  bool _isInit = true;
  bool isLoading = true;
  @override
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_isInit) {
      Provider.of<Auth>(context, listen: false).getFirebaseUser().then((value) {
        Provider.of<Tuitions>(context, listen: false)
            .fetchAndSetTuitions()
            .then((value) => setState(() {
                  uid = Provider.of<Auth>(context, listen: false)
                      .firebaseUser!
                      .uid
                      .toString();
                  currTuition = Provider.of<Tuitions>(context, listen: false)
                      .getTuition(uid.toString());
                  isLoading = false;
                }));
      });
    }
    _isInit = false;
  }

  int _currentIndex = 0;

  void _onTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  TextEditingController search = TextEditingController();
  static List<Widget> _tabs = <Widget>[
    TuitionHome(currTuition),
    Center(
      child: Text(
        'Chat Feature Not Available!',
        style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.bold,
            color: CustomColors.primaryColor),
      ),
    ),
    TuitionReviewsPage(currTuition!),
    TutionMap(currTuition!)

    // Profile(),
  ];
  @override
  Widget build(BuildContext context) {
    return isLoading
        ? LoadingScreen()
        : Scaffold(
            body: _tabs.elementAt(_currentIndex),
            bottomNavigationBar: Container(
              decoration: BoxDecoration(
           borderRadius: BorderRadius.only(
            topRight: Radius.circular(30), topLeft: Radius.circular(30)),
        boxShadow: [
          BoxShadow(color: Colors.black38, spreadRadius: 0, blurRadius: 10),
        ],
        ),
              child: ClipRRect(
                borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30.0),
          topRight: Radius.circular(30.0),),
                child: BottomNavigationBar(
                  // backgroundColor: CustomColors.secondaryColor,
                  selectedItemColor: CustomColors.buttonColor,
                  unselectedItemColor: CustomColors.textColor,
                  items: [
                    BottomNavigationBarItem(
                      icon: Icon(Icons.home),
                      label: "Home",
                      backgroundColor: Colors.white
                      // title: Text('Home'),
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.chat),
                      label: "chat",
                      backgroundColor: Colors.black
                      // title: Text('chat'),
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.reviews),
                      label: "reviews",
                      backgroundColor: Colors.black
                      // title: Text('reviews'),
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(Icons.map),
                      label: "Maps",
                      backgroundColor: Colors.black),
                      // title: Text('Maps'),
                  
                  ],
                   type: BottomNavigationBarType.shifting,
                  onTap: _onTapped,
                ),
              ),
            ));
  }
}
