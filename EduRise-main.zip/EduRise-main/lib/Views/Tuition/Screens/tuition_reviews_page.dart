import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Models/student.dart';
import 'package:edurise/Models/tuition.dart';
import 'package:edurise/Provider/students.dart';
import 'package:edurise/Views/Additional/loading_screen.dart';
import 'package:edurise/Views/Tuition/Screens/tuition_dashboard.dart';
import 'package:edurise/Views/widgets/review_card.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class TuitionReviewsPage extends StatefulWidget {
  final Tuition currTuition;
  TuitionReviewsPage(this.currTuition);

  @override
  _TuitionReviewsPageState createState() => _TuitionReviewsPageState();
}

class _TuitionReviewsPageState extends State<TuitionReviewsPage> {
  List<Map<String, String>> reviews = [];
  Student? reviewer;
  String? reviewerName;

  bool isLoading = true;

  @override
  void didChangeDependencies() {
    widget.currTuition.reviews!.forEach((key, value) async {
      if (mounted) {
        await Provider.of<Students>(context, listen: false)
            .fetchAndSetStudents()
            .then((v) => setState(() {
                  reviewer = Provider.of<Students>(context, listen: false)
                      .getStudent(key);
                  reviewerName = reviewer!.studentName;
                  Map<String, String> m = {reviewerName!: value};
                  reviews.add(m);
                  isLoading = false;
                }));
      }
    });

    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return isLoading
        ? LoadingScreen()
        : Material(
            child: SingleChildScrollView(
                child: Container(
                    color: CustomColors.secondaryColor,
                    height: height,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: height * 0.08,
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            TuitionDashBoard()),
                                  );
                                },
                                child: AnimatedContainer(
                                  duration: Duration(seconds: 1),
                                  width: height / 18,
                                  height: height * 0.05,
                                  child: Icon(
                                    Icons.arrow_back,
                                    color: CustomColors.buttonColor,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white70,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 80),
                                child: Container(
                                    child: Text(
                                  "Reviews by Users",
                                  style: TextStyle(
                                      fontSize: 22,
                                      color: CustomColors.textColor),
                                )),
                              )
                            ],
                          ),
                        ),
                        SizedBox(height: height * 0.02),
                        Container(
                          height: height * 0.8,
                          child: ListView.builder(
                            itemCount: reviews.length,
                            itemBuilder: (BuildContext context, int index) {
                              return ReviewCard(reviews[index]);
                            },
                          ),
                        ),
                      ],
                    ))),
          );
    // child: Container(
    //   height: height,
    //   child: ListView.builder(
    //     itemCount: reviews.length,
    //     itemBuilder: (BuildContext context, int index) {
    //       return ReviewCard(reviews[index]);
    //     },
    //   ),
    // ),
    // );
  }
}
