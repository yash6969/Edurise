import 'dart:math';

import 'package:edurise/Models/tuition.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class TutionMap extends StatefulWidget {
  final Tuition? currTuition;
  TutionMap(this.currTuition);
  @override
  _TutionMapState createState() => _TutionMapState();
}

class _TutionMapState extends State<TutionMap> {
  List<Marker> allMarkers = [];

  void initState() {
    super.initState();
    Future.microtask(() {
      // var r = Random();
      // for (var x = 0; x < maxMarkersCount; x++) {
      widget.currTuition!.usersLocations!.forEach((key, value) {
        double lat = double.parse(key.substring(1, 7));
        double long = double.parse(value.substring(1, 7));
        // debugPrint("$lat");
        // debugPrint("$long");

        allMarkers.add(
          Marker(
            point: LatLng(lat, long),
            builder: (context) => const Icon(
              Icons.circle,
              color: Colors.red,
              size: 12.0,
            ),
          ),
        );
      });

      // }
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return FlutterMap(
      options: MapOptions(
        center: LatLng(28.644800, 77.216721),
        zoom: 4.0,
      ),
      layers: [
        TileLayerOptions(
          urlTemplate: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
          subdomains: ['a', 'b', 'c'],
          // attributionBuilder: (_) {
          //   return Text("© OpenStreetMap contributors");
          // },
        ),
        MarkerLayerOptions(
          markers: allMarkers,
        ),
      ],
    );
  }
}
