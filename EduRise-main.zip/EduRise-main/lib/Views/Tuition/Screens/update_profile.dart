import 'dart:io';

import 'package:badges/badges.dart';
import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Models/tuition.dart';
import 'package:edurise/Provider/auth.dart';
import 'package:edurise/Provider/tuitions.dart';
import 'package:edurise/Views/Additional/landing_page.dart';
import 'package:edurise/Views/widgets/msg_toast.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

class UpdateProfile extends StatefulWidget {
  Tuition? currTuition;
  UpdateProfile(this.currTuition);

  @override
  _UpdateProfileState createState() => _UpdateProfileState();
}

class _UpdateProfileState extends State<UpdateProfile> {
  TextEditingController tuitionNameController = new TextEditingController();
  TextEditingController addressController = new TextEditingController();
  TextEditingController pincodeController = new TextEditingController();
  TextEditingController ownerNameController = new TextEditingController();
  TextEditingController descriptionController = new TextEditingController();
  TextEditingController achievementsController = new TextEditingController();
  TextEditingController subjectsController = new TextEditingController();
  TextEditingController classesController = new TextEditingController();
  TextEditingController tuitionFeeController = new TextEditingController();

  bool iskeyboardvisible = false;

  final _formKey = GlobalKey<FormState>();
  bool isEdit = false;

  String? uid;
  String? mobileNumber;
  Tuition? newTuition;
  String modeofteaching = "Offline";

  var _image;
  var imageUrl;
  var imagePicker;

  @override
  void initState() {
    super.initState();
    tuitionNameController.text = widget.currTuition!.tuitionName.toString();
    addressController.text = widget.currTuition!.address.toString();
    pincodeController.text = widget.currTuition!.pincode.toString();
    ownerNameController.text = widget.currTuition!.ownerName.toString();
    descriptionController.text =
        widget.currTuition!.tuitionDescription.toString();
    achievementsController.text = widget.currTuition!.achievements.toString();
    subjectsController.text = widget.currTuition!.subjects.toString();
    classesController.text = widget.currTuition!.classes.toString();
    tuitionFeeController.text = widget.currTuition!.fee.toString();
    modeofteaching = widget.currTuition!.modeOfTeaching.toString();
    isEdit = false;
  }

  uploadImage() async {
    final _firebaseStorage = FirebaseStorage.instance;
    final imagePicker = ImagePicker();

    await Permission.photos.request();
    var permissionStatus = await Permission.photos.status;

    if (permissionStatus.isGranted) {
      var image = await imagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 50,
      );
      setState(() {
        _image = File(image!.path);
      });
      uid = Provider.of<Auth>(context, listen: false)
          .firebaseUser!
          .uid
          .toString();
      if (_image != null) {
        var snapshot = await _firebaseStorage
            .ref()
            .child('TuitionImages/$uid')
            .putFile(_image);
        var downloadUrl = await snapshot.ref.getDownloadURL();
        setState(() {
          imageUrl = downloadUrl;
        });
      } else {
       // print('No Image Path Received');
      }
    } else {
      //print('Permission not granted. Try Again with permission access');
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return isEdit
        ? Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            child: Material(
              color: CustomColors.secondaryColor,
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      SizedBox(
                        height: height / 12,
                      ),
                      Row(
                        children: [
                          SizedBox(
                            width: width * 0.82,
                          ),
                          AnimatedContainer(
                            duration: Duration(seconds: 1),
                            width: height / 18,
                            height: height / 18,
                            child: Image.asset(
                              "assets/images/logo_transparent.png",
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: height / 30,
                      ),
                      Text(
                        "Update Your Profile",
                        style: TextStyle(
                          fontSize: height / 35,
                          fontWeight: FontWeight.bold,
                          color: CustomColors.textColor,
                        ),
                      ),
                      SizedBox(
                        height: height / 12,
                      ),
                      InkWell(
                        onTap: () async {
                          await uploadImage();
                        },
                        child: Container(
                          width: width / 3,
                          height: width / 3,
                          decoration: BoxDecoration(
                            color: Colors.red[200],
                          ),
                          child: _image != null
                              ? Image.file(
                                  _image,
                                  width: width / 3,
                                  height: width / 3,
                                  fit: BoxFit.fitHeight,
                                )
                              : Container(
                                  decoration:
                                      BoxDecoration(color: Colors.red[200]),
                                  width: width / 3,
                                  height: width / 3,
                                  child: Icon(
                                    Icons.camera_alt,
                                    color: Colors.grey[800],
                                  ),
                                ),
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: tuitionNameController,
                          autocorrect: true,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText: "Ex: Lakshya JEE Classes",
                            labelText: "Tuition Name",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Tuition must have a Name";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: addressController,
                          autocorrect: true,
                          maxLines: 5,
                          minLines: 2,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText: "Please add complete Address",
                            labelText: "Tuition Address",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Must be filled";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: pincodeController,
                          autocorrect: true,
                          keyboardType: TextInputType.number,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText: "Ex: 307261",
                            labelText: "Pincode",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.length != 6) {
                              return "Invalid Pincode";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: ownerNameController,
                          autocorrect: true,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText: "Enter Name of Owner of Tuition",
                            labelText: "Owner Name",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Must be filled";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: descriptionController,
                          autocorrect: true,
                          maxLines: 5,
                          minLines: 2,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText:
                                "Ex: Lakshya JEE Classes is founded in 2019 by Mr. Alex. Our Aim is to crack the Aim of the Students. ",
                            labelText: "About us",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Please add something";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: achievementsController,
                          autocorrect: true,
                          maxLines: 5,
                          minLines: 2,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText:
                                "Ex: 2 Students got selected in JEE Advances 2020, Ramesh Secured 1st rank in district in RBSE 2020",
                            labelText: "Previous Achievements",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Must be filled";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: subjectsController,
                          autocorrect: true,
                          maxLines: 5,
                          minLines: 2,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText:
                                "Ex: Mathematics, Computer Science, Dance, Music etc",
                            labelText: "Subjects",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Please Add something";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: classesController,
                          autocorrect: true,
                          maxLines: 5,
                          minLines: 2,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText: "Ex: 1-5, 8-10, BSc, B.Tech(CSE)",
                            labelText: "Classes",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Please Add something";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: tuitionFeeController,
                          autocorrect: true,
                          maxLines: 5,
                          minLines: 2,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText:
                                "Ex: 1000 rupees/month for class 1-5, 2000 rupees/month for B-tech etc",
                            labelText: "Tuition Fee Details",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Please Add something";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Mode of Teaching ",
                              style: TextStyle(
                                  color: CustomColors.primaryColor,
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: width * 0.08,
                            ),
                            DropdownButton<String>(
                              focusColor: CustomColors.primaryColor,
                              iconEnabledColor: CustomColors.primaryColor,
                              iconDisabledColor: CustomColors.primaryColor,
                              // borderRadius: BorderRadius.circular(20),
                              value: modeofteaching,
                              style: TextStyle(
                                  color: CustomColors.primaryColor,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold),
                              items: <String>[
                                'Online',
                                'Offline',
                                'Online and Offline both'
                              ].map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                              onChanged: (value) {
                                setState(() {
                                  modeofteaching = value!;
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: height / 15,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          InkWell(
                            onTap: () => {
                              setState(() {
                                isEdit = false;
                              })
                            },
                            child: AnimatedContainer(
                              duration: Duration(seconds: 1),
                              width: width / 2.9,
                              height: height / 17,
                              alignment: Alignment.center,
                              child: Text(
                                "Cancel",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: height / 45,
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: CustomColors.buttonColor,
                                borderRadius: BorderRadius.circular(15),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: width / 10,
                          ),
                          InkWell(
                            onTap: () async => {
                              if (_formKey.currentState!.validate())
                                {
                                  await Provider.of<Auth>(context,
                                          listen: false)
                                      .getFirebaseUser(),
                                  uid =
                                      Provider.of<Auth>(context, listen: false)
                                          .firebaseUser!
                                          .uid
                                          .toString(),
                                  newTuition = widget.currTuition!.copyWith(
                                    tuitionName:
                                        tuitionNameController.text.toString(),
                                    address: addressController.text.toString(),
                                    ownerName:
                                        ownerNameController.text.toString(),
                                    pincode: pincodeController.text.toString(),
                                    tuitionDescription:
                                        descriptionController.text.toString(),
                                    achievements:
                                        achievementsController.text.toString(),
                                    subjects:
                                        subjectsController.text.toString(),
                                    classes: classesController.text.toString(),
                                    fee: tuitionFeeController.text.toString(),
                                    modeOfTeaching: modeofteaching.toString(),
                                  ),
                                  await Provider.of<Tuitions>(context,
                                          listen: false)
                                      .updateTuition(newTuition!),
                                  setState(() {
                                    isEdit = false;
                                  })
                                }
                            },
                            child: AnimatedContainer(
                              duration: Duration(seconds: 1),
                              width: width / 2.9,
                              height: height / 17,
                              alignment: Alignment.center,
                              child: Text(
                                "Save",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: height / 45,
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: CustomColors.buttonColor,
                                borderRadius: BorderRadius.circular(15),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: height / 15,
                      )
                    ],
                  ),
                ),
              ),
            ),
          )
        : Scaffold(
            backgroundColor: CustomColors.secondaryColor,
            body: SingleChildScrollView(
              child: Container(
                color: CustomColors.secondaryColor,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Badge(
                      position: BadgePosition(bottom: -25),
                      badgeColor: Colors.white,
                      toAnimate: false,
                      shape: BadgeShape.square,
                      borderRadius: BorderRadius.all(Radius.circular(50)),
                      badgeContent: Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius:
                                BorderRadius.all(Radius.circular(20))),
                        height: height / 23,
                        width: width / 3.5,
                        child: Center(
                            child: InkWell(
                                onTap: () {
                                 // print("enroll service");
                                  msgToast(
                                      "This service is only for students!");
                                },
                                child: Text("Enroll",
                                    style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black)))),
                      ),
                      child: Container(
                        height: height / 3,
                        width: width,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage('assets/images/institute.png')),
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(20),
                              bottomRight: Radius.circular(20)),
                          color: CustomColors.primaryColor,
                        ),
                        child: Stack(
                          children: [
                            Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    widget.currTuition!.tuitionName,
                                    style: TextStyle(
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: height * 0.05,
                    ),
                    Container(
                      // height: height,
                      width: width,

                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Text("About us",
                                style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 100,
                            ),
                            Text(widget.currTuition!.tuitionDescription,
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.normal,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 20,
                            ),

                            Text("Our Previous Achievements",
                                style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 100,
                            ),
                            Text(widget.currTuition!.achievements,
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.normal,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 20,
                            ),

                            ///
                            ////
                            ///
                            Text("Address",
                                style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 100,
                            ),
                            Text(
                                widget.currTuition!.address +
                                    ", Pincode: " +
                                    widget.currTuition!.pincode,
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.normal,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 20,
                            ),
                            ////
                            /////
                            ///
                            Text("Which class can Enroll",
                                style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 100,
                            ),
                            Text(widget.currTuition!.classes,
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.normal,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 20,
                            ),

                            ///
                            ///
                            ///
                            Text("Subjects",
                                style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 100,
                            ),
                            Text(widget.currTuition!.subjects,
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.normal,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 20,
                            ),

                            ///
                            ///
                            ///
                            Text("Tuition Fee Details",
                                style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 100,
                            ),
                            Text(widget.currTuition!.fee,
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.normal,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 20,
                            ),

                            ///
                            ///
                            ///
                            Text("Mode of Teaching: ",
                                style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 100,
                            ),
                            Text(widget.currTuition!.modeOfTeaching,
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.normal,
                                    color: Colors.black)),
                            SizedBox(
                              height: height / 20,
                            ),
                            Text("Gallery",
                                style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black)),
                            //       SizedBox(
                            //   height: height / 20,
                            // ),
                            FutureBuilder(
                              future:
                                  Provider.of<Tuitions>(context, listen: false)
                                      .getImageUrl(
                                          widget.currTuition!.uid.toString()),
                              builder: (context, snapshot) {
                                if (snapshot.hasData) {
                                  return Padding(
                                    padding: const EdgeInsets.all(16.0),
                                    child: Container(
                                      // width: width,
                                      height: height / 3,
                                      decoration: BoxDecoration(
                                          image: DecorationImage(
                                              image: NetworkImage(
                                        snapshot.data.toString(),
                                      ))),
                                    ),
                                  );
                                } else if (snapshot.hasError) {
                                  return Icon(Icons.image_not_supported_sharp);
                                } else {
                                  // return CircleAvatar(
                                  //   radius: width / 8,
                                  //   backgroundColor:
                                  //       CustomColors.boxColourWithOpacity,
                                  //   foregroundColor:
                                  //       CustomColors.boxColourWithOpacity,
                                  //   child: CircularProgressIndicator(),
                                  // );
                                  return Padding(
                                      padding: const EdgeInsets.all(16.0),
                                      child: Container(
                                        // width: width,
                                        height: height / 3,
                                      ));
                                }
                              },
                            ),
                            // SizedBox(
                            //   height: height / 20,
                            // ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                      color: CustomColors.primaryColor,
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(30))),
                                  height: height / 16,
                                  width: width / 3,
                                  child: Center(
                                      child: InkWell(
                                          onTap: () {
                                            setState(() {
                                              isEdit = true;
                                            });
                                          },
                                          child: Text("Edit Details",
                                              style: TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.white)))),
                                ),
                                SizedBox(
                                  width: width / 10,
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                      color: CustomColors.primaryColor,
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(30))),
                                  height: height / 16,
                                  width: width / 3,
                                  child: Center(
                                      child: InkWell(
                                          onTap: () async {
                                            showAlertDialog(context);
                                          },
                                          child: Text("Sign Out",
                                              style: TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.white)))),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: height / 20,
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ));
  }
}

showAlertDialog(BuildContext context) {
  // Create button
  Widget okButton = Row(
    children: [
      TextButton(
        child: Text("Yes"),
        onPressed: () async {
          await Provider.of<Auth>(context, listen: false).logout();

          Navigator.pushAndRemoveUntil(context,
              MaterialPageRoute(builder: (context) {
            return LandingPage();
          }), (route) => false);
        },
      ),
      TextButton(
        child: Text("No"),
        onPressed: () => Navigator.pop(context),
      )
    ],
  );

  // Create AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("Logout"),
    content: Text("Are you sure you want to Logout?"),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
