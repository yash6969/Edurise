import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Models/tuition.dart';
import 'package:edurise/Provider/auth.dart';
import 'package:edurise/Provider/tuitions.dart';
import 'package:edurise/Views/Additional/loading_screen.dart';
import 'package:edurise/Views/Tuition/TuitionRegistration/tuitionregistrationform2.dart';
import 'package:edurise/Views/Tuition/TuitionRegistration/tuition_login.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';

class TuitionRegisterForm1 extends StatefulWidget {
  @override
  _TuitionRegisterForm1State createState() => _TuitionRegisterForm1State();
}

class _TuitionRegisterForm1State extends State<TuitionRegisterForm1> {
  TextEditingController tuitionNameController = new TextEditingController();
  TextEditingController addressController = new TextEditingController();
  TextEditingController pincodeController = new TextEditingController();
  TextEditingController ownerNameController = new TextEditingController();

  bool iskeyboardvisible = false;

  final _formKey = GlobalKey<FormState>();

  String? uid;
  String? mobileNumber;
  String? pincodeLocation;
  bool isLoading = true;
  String? longi, lati;

  Map<String, String>? tuitionLocation;
  Map<String, String> userLocations = {};
  Map<String, String> reviews = {};

  Future<String?> _getLocation() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.bestForNavigation);

    var longitude = position.longitude;
    var latitude = position.latitude;

    longi = longitude.toString().substring(0, 7);
    lati = latitude.toString().substring(0, 7);

    tuitionLocation = {lati!: longi!};

    List<Placemark> placemarks =
        await placemarkFromCoordinates(latitude, longitude);

    // print(placemarks.first.postalCode);
    pincodeLocation = placemarks.first.postalCode;
    setState(() {
      isLoading = false;
      pincodeLocation = placemarks.first.postalCode;
      longi = longitude.toString().substring(0, 7);
      lati = latitude.toString().substring(0, 7);
    });
    return pincodeLocation;
  }

  @override
  void initState() {
    _getLocation();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return isLoading
        ? LoadingScreen()
        : Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            child: Material(
              color: CustomColors.secondaryColor,
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      SizedBox(
                        height: height / 12,
                      ),
                      Row(
                        children: [
                          SizedBox(
                            width: width * 0.82,
                          ),
                          AnimatedContainer(
                            duration: Duration(seconds: 1),
                            width: height / 18,
                            height: height / 18,
                            child: Image.asset(
                              "assets/images/logo_transparent.png",
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: height / 30,
                      ),
                      Text(
                        "Tuition Registration",
                        style: TextStyle(
                          fontSize: height / 35,
                          fontWeight: FontWeight.bold,
                          color: CustomColors.textColor,
                        ),
                      ),
                      SizedBox(
                        height: height / 12,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: tuitionNameController,
                          autocorrect: true,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText: "Ex: Lakshya JEE Classes",
                            labelText: "Enter Your Tuition Name",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Tuition must have a Name";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: addressController,
                          autocorrect: true,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText: "Please add complete Address",
                            labelText: "Tuition Address",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Must be filled";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: pincodeController,
                          autocorrect: true,
                          keyboardType: TextInputType.number,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText: "Ex: 307261",
                            labelText: "Pincode",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.length != 6) {
                              return "Invalid Pincode";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: ownerNameController,
                          autocorrect: true,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText: "Enter Name of Owner of Tuition",
                            labelText: "Owner Name",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Must be filled";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 15,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          InkWell(
                            onTap: () => {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => TuitionLoginPage()))
                            },
                            child: AnimatedContainer(
                              duration: Duration(seconds: 1),
                              width: width / 2.9,
                              height: height / 17,
                              alignment: Alignment.center,
                              child: Text(
                                "Cancel",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: height / 45,
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: CustomColors.buttonColor,
                                borderRadius: BorderRadius.circular(15),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: width / 10,
                          ),
                          InkWell(
                            onTap: () async => {
                              if (_formKey.currentState!.validate())
                                {
                                  // List<Faculty> faculties = [];

                                  await Provider.of<Auth>(context,
                                          listen: false)
                                      .getFirebaseUser(),
                                  uid =
                                      Provider.of<Auth>(context, listen: false)
                                          .firebaseUser!
                                          .uid
                                          .toString(),
                                  mobileNumber =
                                      Provider.of<Auth>(context, listen: false)
                                          .firebaseUser!
                                          .phoneNumber
                                          .toString(),

                                  Provider.of<Tuitions>(context, listen: false)
                                      .addTuition(
                                    Tuition(
                                        uid: uid.toString(),
                                        tuitionName: tuitionNameController.text
                                            .toString(),
                                        mobileNumber: mobileNumber.toString(),
                                        address:
                                            addressController.text.toString(),
                                        pincode:
                                            pincodeController.text.toString(),
                                        ownerName:
                                            ownerNameController.text.toString(),
                                        tuitionDescription: "",
                                        achievements: "",
                                        numberOfFaculties: 0,
                                        faculty: [],
                                        subjects: "",
                                        classes: "",
                                        fee: "",
                                        modeOfTeaching: "",
                                        reviews: reviews,
                                        reach: 0,
                                        views: 0,
                                        usersLocations: userLocations,
                                        tuitionLocation: tuitionLocation),
                                  ),
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              TuitionRegisterForm2()))
                                }
                            },
                            child: AnimatedContainer(
                              duration: Duration(seconds: 1),
                              width: width / 2.9,
                              height: height / 17,
                              alignment: Alignment.center,
                              child: Text(
                                "Submit",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: height / 45,
                                ),
                              ),
                              decoration: BoxDecoration(
                                color: CustomColors.buttonColor,
                                borderRadius: BorderRadius.circular(15),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: height / 15,
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
  }
}
