import 'dart:io';

import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Models/tuition.dart';
import 'package:edurise/Provider/auth.dart';
import 'package:edurise/Provider/tuitions.dart';

import 'package:edurise/Views/Tuition/Screens/tuition_dashboard.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

class TuitionRegisterForm2 extends StatefulWidget {
  @override
  _TuitionRegisterForm2State createState() => _TuitionRegisterForm2State();
}

class _TuitionRegisterForm2State extends State<TuitionRegisterForm2> {
  TextEditingController descriptionController = new TextEditingController();
  TextEditingController achievementsController = new TextEditingController();
  TextEditingController subjectsController = new TextEditingController();
  TextEditingController classesController = new TextEditingController();
  TextEditingController tuitionFeeController = new TextEditingController();

  Tuition? currTuition;
  Tuition? newTuition;
  String? uid;

  final _formKey = GlobalKey<FormState>();
  String modeofteaching = "Offline";

  var _image;
  var imageUrl;
  var imagePicker;

  bool _isInit = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_isInit) {
      Provider.of<Auth>(context, listen: false).getFirebaseUser().then((value) {
        Provider.of<Tuitions>(context, listen: false)
            .fetchAndSetTuitions()
            .then((value) => setState(() {
                  uid = Provider.of<Auth>(context, listen: false)
                      .firebaseUser!
                      .uid
                      .toString();
                  currTuition = Provider.of<Tuitions>(context, listen: false)
                      .getTuition(uid.toString());
                }));
      });
    }
    _isInit = false;
  }

  uploadImage() async {
    final _firebaseStorage = FirebaseStorage.instance;
    final imagePicker = ImagePicker();

    await Permission.photos.request();
    var permissionStatus = await Permission.photos.status;

    if (permissionStatus.isGranted) {
      var image = await imagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 50,
      );
      setState(() {
        _image = File(image!.path);
      });
      uid = Provider.of<Auth>(context, listen: false)
          .firebaseUser!
          .uid
          .toString();
      if (_image != null) {
        var snapshot = await _firebaseStorage
            .ref()
            .child('TuitionImages/$uid')
            .putFile(_image);
        var downloadUrl = await snapshot.ref.getDownloadURL();
        setState(() {
          imageUrl = downloadUrl;
        });
      } else {
       // print('No Image Path Received');
      }
    } else {
     // print('Permission not granted. Try Again with permission access');
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Material(
        color: CustomColors.secondaryColor,
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                SizedBox(
                  height: height / 12,
                ),
                Row(
                  children: [
                    SizedBox(
                      width: width * 0.82,
                    ),
                    AnimatedContainer(
                      duration: Duration(seconds: 1),
                      width: height / 18,
                      height: height / 18,
                      child: Image.asset(
                        "assets/images/logo_transparent.png",
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: height / 30,
                ),
                Text(
                  "Additional Information",
                  style: TextStyle(
                    fontSize: height / 35,
                    fontWeight: FontWeight.bold,
                    color: CustomColors.textColor,
                  ),
                ),
                SizedBox(
                  height: height / 15,
                ),
                InkWell(
                  onTap: () async {
                    await uploadImage();
                  },
                  child: Container(
                    width: width / 3,
                    height: width / 3,
                    decoration: BoxDecoration(
                      color: Colors.red[200],
                    ),
                    child: _image != null
                        ? Image.file(
                            _image,
                            width: width / 3,
                            height: width / 3,
                            fit: BoxFit.fitHeight,
                          )
                        : Container(
                            decoration: BoxDecoration(color: Colors.red[200]),
                            width: width / 3,
                            height: width / 3,
                            child: Icon(
                              Icons.camera_alt,
                              color: Colors.grey[800],
                            ),
                          ),
                  ),
                ),
                SizedBox(
                  height: height / 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 35, right: 35),
                  child: TextFormField(
                    cursorColor: CustomColors.toyoPrimaryColor,
                    controller: descriptionController,
                    autocorrect: true,
                    maxLines: 5,
                    minLines: 2,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                      color: CustomColors.toyoPrimaryColor,
                    ),
                    decoration: InputDecoration(
                      hintText:
                          "Ex: Lakshya JEE Classes is founded in 2019 by Mr. Alex. Our Aim is to crack the Aim of the Students. ",
                      labelText: "About us",
                      filled: true,
                      fillColor: CustomColors.secondaryColor,
                      labelStyle: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                          color: CustomColors.primaryColor),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: CustomColors.primaryColor,
                          width: 2.0,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: CustomColors.primaryColor,
                          width: 2.0,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Please add something";
                      }
                      return null;
                    },
                  ),
                ),
                SizedBox(
                  height: height / 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 35, right: 35),
                  child: TextFormField(
                    cursorColor: CustomColors.toyoPrimaryColor,
                    controller: achievementsController,
                    autocorrect: true,
                    maxLines: 5,
                    minLines: 2,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                      color: CustomColors.toyoPrimaryColor,
                    ),
                    decoration: InputDecoration(
                      hintText:
                          "Ex: 2 Students got selected in JEE Advances 2020, Ramesh Secured 1st rank in district in RBSE 2020",
                      labelText: "Previous Achievements",
                      filled: true,
                      fillColor: CustomColors.secondaryColor,
                      labelStyle: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                          color: CustomColors.primaryColor),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: CustomColors.primaryColor,
                          width: 2.0,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: CustomColors.primaryColor,
                          width: 2.0,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Must be filled";
                      }
                      return null;
                    },
                  ),
                ),
                SizedBox(
                  height: height / 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 35, right: 35),
                  child: TextFormField(
                    cursorColor: CustomColors.toyoPrimaryColor,
                    controller: subjectsController,
                    autocorrect: true,
                    maxLines: 5,
                    minLines: 2,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                      color: CustomColors.toyoPrimaryColor,
                    ),
                    decoration: InputDecoration(
                      hintText:
                          "Ex: Mathematics, Computer Science, Dance, Music etc",
                      labelText: "Subjects",
                      filled: true,
                      fillColor: CustomColors.secondaryColor,
                      labelStyle: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                          color: CustomColors.primaryColor),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: CustomColors.primaryColor,
                          width: 2.0,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: CustomColors.primaryColor,
                          width: 2.0,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Please Add something";
                      }
                      return null;
                    },
                  ),
                ),
                SizedBox(
                  height: height / 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 35, right: 35),
                  child: TextFormField(
                    cursorColor: CustomColors.toyoPrimaryColor,
                    controller: classesController,
                    autocorrect: true,
                    maxLines: 5,
                    minLines: 2,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                      color: CustomColors.toyoPrimaryColor,
                    ),
                    decoration: InputDecoration(
                      hintText: "Ex: 1-5, 8-10, BSc, B.Tech(CSE)",
                      labelText: "Classes",
                      filled: true,
                      fillColor: CustomColors.secondaryColor,
                      labelStyle: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                          color: CustomColors.primaryColor),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: CustomColors.primaryColor,
                          width: 2.0,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: CustomColors.primaryColor,
                          width: 2.0,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Please Add something";
                      }
                      return null;
                    },
                  ),
                ),
                SizedBox(
                  height: height / 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 35, right: 35),
                  child: TextFormField(
                    cursorColor: CustomColors.toyoPrimaryColor,
                    controller: tuitionFeeController,
                    autocorrect: true,
                    maxLines: 5,
                    minLines: 2,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                      color: CustomColors.toyoPrimaryColor,
                    ),
                    decoration: InputDecoration(
                      hintText:
                          "Ex: 1000 rupees/month for class 1-5, 2000 rupees/month for B-tech etc",
                      labelText: "Tuition Fee Details",
                      filled: true,
                      fillColor: CustomColors.secondaryColor,
                      labelStyle: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                          color: CustomColors.primaryColor),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: CustomColors.primaryColor,
                          width: 2.0,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: CustomColors.primaryColor,
                          width: 2.0,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Please Add something";
                      }
                      return null;
                    },
                  ),
                ),
                SizedBox(
                  height: height / 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 35, right: 35),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Mode of Teaching ",
                        style: TextStyle(
                            color: CustomColors.primaryColor,
                            fontSize: 17,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: width * 0.08,
                      ),
                      DropdownButton<String>(
                        focusColor: CustomColors.primaryColor,
                        iconEnabledColor: CustomColors.primaryColor,
                        iconDisabledColor: CustomColors.primaryColor,
                        // borderRadius: BorderRadius.circular(20),
                        value: modeofteaching,
                        style: TextStyle(
                            color: CustomColors.primaryColor,
                            fontSize: 15,
                            fontWeight: FontWeight.bold),
                        items: <String>[
                          'Online',
                          'Offline',
                          'Online and Offline both'
                        ].map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            modeofteaching = value!;
                          });
                        },
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: height / 15,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () => {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => TuitionDashBoard()))
                      },
                      child: AnimatedContainer(
                        duration: Duration(seconds: 1),
                        width: width / 2.9,
                        height: height / 17,
                        alignment: Alignment.center,
                        child: Text(
                          "Skip for Now",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: height / 45,
                          ),
                        ),
                        decoration: BoxDecoration(
                          color: CustomColors.buttonColor,
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: width / 10,
                    ),
                    InkWell(
                      onTap: () async => {
                        if (_formKey.currentState!.validate())
                          {
                            currTuition =
                                Provider.of<Tuitions>(context, listen: false)
                                    .getTuition(uid.toString()),
                            newTuition = currTuition!.copyWith(
                              tuitionDescription:
                                  descriptionController.text.toString(),
                              achievements:
                                  achievementsController.text.toString(),
                              subjects: subjectsController.text.toString(),
                              classes: classesController.text.toString(),
                              fee: tuitionFeeController.text.toString(),
                              modeOfTeaching: modeofteaching.toString(),
                            ),
                            await Provider.of<Tuitions>(context, listen: false)
                                .updateTuition(newTuition!),
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => TuitionDashBoard()))
                          }
                      },
                      child: AnimatedContainer(
                        duration: Duration(seconds: 1),
                        width: width / 2.9,
                        height: height / 17,
                        alignment: Alignment.center,
                        child: Text(
                          "Submit",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: height / 45,
                          ),
                        ),
                        decoration: BoxDecoration(
                          color: CustomColors.buttonColor,
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                    )
                  ],
                ),
                SizedBox(
                  height: height / 15,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
