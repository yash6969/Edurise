import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Provider/auth.dart';
import 'package:edurise/Views/Additional/landing_page.dart';
import 'package:edurise/Views/Additional/loading_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class TuitionLoginPage extends StatefulWidget {
  @override
  _TuitionLoginPageState createState() => _TuitionLoginPageState();
}

class _TuitionLoginPageState extends State<TuitionLoginPage> {
  bool? iscorrectformat;
  TextEditingController phoneController = new TextEditingController();

  final _formKey = GlobalKey<FormState>();
  bool showLoading = false;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return showLoading
        ? LoadingScreen()
        : Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            child: Material(
              color: CustomColors.secondaryColor,
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      SizedBox(
                        height: height / 15,
                      ),
                      Row(
                        children: [
                          SizedBox(
                            width: width / 20,
                          ),
                          InkWell(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LandingPage()),
                              );
                            },
                            child: AnimatedContainer(
                              duration: Duration(seconds: 1),
                              width: height / 18,
                              height: height / 18,
                              child: Icon(
                                Icons.arrow_back,
                                color: CustomColors.buttonColor,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white70,
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Image.asset(
                        "assets/images/logo_transparent.png",
                        height: height / 4.5,
                        width: width / 2,
                      ),
                      SizedBox(
                        height: height / 60,
                      ),
                      Text(
                        "Tuition Login/Register",
                        style: TextStyle(
                          fontSize: height / 40,
                          fontWeight: FontWeight.bold,
                          color: CustomColors.textColor,
                        ),
                      ),
                      SizedBox(
                        height: height / 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: phoneController,
                          autocorrect: true,
                          keyboardType: TextInputType.number,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText: "Ex: 9016XXXXXX",
                            labelText: "Enter Your Mobile Number",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value!.length < 10) {
                              return "Please enter valid Mobile Number";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: height / 15,
                      ),
                      InkWell(
                        onTap: () async => {
                          if (_formKey.currentState!.validate())
                            {
                              setState(() {
                                showLoading = true;
                              }),
                              await Provider.of<Auth>(context, listen: false)
                                  .submitPhoneNumberTuition(
                                      phoneController.text.toString(), context),
                            }
                        },
                        child: AnimatedContainer(
                          duration: Duration(seconds: 1),
                          width: width / 1.8,
                          height: height / 16,
                          alignment: Alignment.center,
                          child: Text(
                            "Login",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: height / 45,
                            ),
                          ),
                          decoration: BoxDecoration(
                            color: CustomColors.buttonColor,
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: height / 12,
                      ),
                      Text(
                        "Wanna Login as Student? click here",
                        style: TextStyle(
                          fontSize: height / 50,
                          fontWeight: FontWeight.bold,
                          color: CustomColors.textColor,
                        ),
                      ),
                      SizedBox(
                        height: height / 80,
                      ),
                      InkWell(
                        onTap: () => {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => LandingPage()))
                        },
                        child: AnimatedContainer(
                          duration: Duration(seconds: 1),
                          width: width / 1.8,
                          height: height / 16,
                          alignment: Alignment.center,
                          child: Text(
                            "Back to Welcome Screen",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: height / 45,
                            ),
                          ),
                          decoration: BoxDecoration(
                            color: CustomColors.buttonColor,
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                      ),
                      SizedBox(height: height / 15)
                    ],
                  ),
                ),
              ),
            ),
          );
  }
}
