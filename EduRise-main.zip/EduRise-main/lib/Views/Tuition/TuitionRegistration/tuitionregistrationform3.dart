import 'package:edurise/Constants/app_theme.dart';
import 'package:flutter/material.dart';

class TuitionRegisterForm3 extends StatefulWidget {
  @override
  _TuitionRegisterForm3State createState() => _TuitionRegisterForm3State();
}

class _TuitionRegisterForm3State extends State<TuitionRegisterForm3> {
  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Material(
        color: CustomColors.secondaryColor,
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: height / 12,
              ),
              Row(
                children: [
                  SizedBox(
                    width: width * 0.82,
                  ),
                  AnimatedContainer(
                    duration: Duration(seconds: 1),
                    width: height / 18,
                    height: height / 18,
                    child: Image.asset(
                      "assets/images/logo_transparent.png",
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: height / 30,
              ),
              Text(
                "Add Faculties",
                style: TextStyle(
                  fontSize: height / 35,
                  fontWeight: FontWeight.bold,
                  color: CustomColors.textColor,
                ),
              ),
              SizedBox(
                height: height / 15,
              ),
              Text(
                "Under Construction",
                style: TextStyle(
                  fontSize: height / 35,
                  fontWeight: FontWeight.bold,
                  color: CustomColors.textColor,
                ),
              ),
              SizedBox(
                height: height / 15,
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: () => {
                      // Navigator.push(
                      //     context,
                      //     MaterialPageRoute(
                      //         builder: (context) => TuitionLoginPage()))
                    },
                    child: AnimatedContainer(
                      duration: Duration(seconds: 1),
                      width: width / 2.9,
                      height: height / 17,
                      alignment: Alignment.center,
                      child: Text(
                        "Skip for Now",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: height / 45,
                        ),
                      ),
                      decoration: BoxDecoration(
                        color: CustomColors.buttonColor,
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: width / 10,
                  ),
                  InkWell(
                    onTap: () => {},
                    child: AnimatedContainer(
                      duration: Duration(seconds: 1),
                      width: width / 2.9,
                      height: height / 17,
                      alignment: Alignment.center,
                      child: Text(
                        "Submit",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: height / 45,
                        ),
                      ),
                      decoration: BoxDecoration(
                        color: CustomColors.buttonColor,
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  )
                ],
              ),
              SizedBox(
                height: height / 15,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
