import 'package:cached_network_image/cached_network_image.dart';
import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Models/student.dart';
import 'package:edurise/Models/tuition.dart';
import 'package:edurise/Provider/auth.dart';
import 'package:edurise/Provider/students.dart';
import 'package:edurise/Provider/tuitions.dart';
import 'package:edurise/Views/Additional/loading_screen.dart';
import 'package:edurise/Views/Guest/widgets/tuition_card_for_guests.dart';
import 'package:edurise/Views/Student/screens/student_profile.dart';
import 'package:edurise/Views/Student/widgets/tuition_card_for_students.dart';
import 'package:edurise/Views/widgets/msg_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';

class StudentDashBoard extends StatefulWidget {
  final Map<String, String> userLocation;
  final String pincode;
  StudentDashBoard(this.pincode, this.userLocation);

  @override
  _StudentDashBoardState createState() => _StudentDashBoardState();
}

class _StudentDashBoardState extends State<StudentDashBoard> {
  List<Tuition> tuitions = [];
  List<Marker> allMarkers = [];

  bool _isInit = true;
  bool isLoading = true;
  String? uid;
  Student? currStudent;
  @override
  Future<void> didChangeDependencies() async {
    super.didChangeDependencies();
    if (_isInit) {
      await Provider.of<Students>(context, listen: false)
          .fetchAndSetStudents()
          .then((value) async => await Provider.of<Auth>(context, listen: false)
                  .getFirebaseUser()
                  .then((value) async {
                await Provider.of<Tuitions>(context, listen: false)
                    .fetchAndSetTuitionswithPincode(widget.pincode)
                    .then((value) => {
                          tuitions.forEach((element) {
                            element.tuitionLocation!.forEach((key, value) {
                              double lat = double.parse(key);
                              double long = double.parse(value);

                              // print("$lat $long");

                              allMarkers.add(
                                Marker(
                                  point: LatLng(lat, long),
                                  builder: (context) => const Icon(
                                    Icons.circle,
                                    color: Colors.red,
                                    size: 12.0,
                                  ),
                                ),
                              );
                            });
                          }),
                          setState(() {
                            tuitions =
                                Provider.of<Tuitions>(context, listen: false)
                                    .tuitionsWithPincode;
                            uid = Provider.of<Auth>(context, listen: false)
                                .firebaseUser!
                                .uid
                                .toString();
                            currStudent =
                                Provider.of<Students>(context, listen: false)
                                    .getStudent(uid.toString());
                            // print("curr= " + currStudent!.studentName);
                            isLoading = false;
                          })
                        });
              }));
    }
    _isInit = false;
  }

  TextEditingController search = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return isLoading
        ? LoadingScreen()
        : DefaultTabController(
            length: 2,
            child: Scaffold(
              appBar: AppBar(
                foregroundColor: CustomColors.primaryColor,
                backgroundColor: CustomColors.secondaryColor,
                title: Text(
                  "Hey ${currStudent!.studentName}!",
                  style: TextStyle(color: CustomColors.primaryColor),
                ),
                actions: [
                  Icon(Icons.dashboard_customize),
                  SizedBox(width: 0.01),
                  FutureBuilder(
                    future: Provider.of<Students>(context, listen: false)
                        .getImageUrl(currStudent!.uid.toString()),
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        return IconButton(
                          icon: CircleAvatar(
                            // minRadius: width / 8,
                            // maxRadius: width / 8,
                            minRadius: width / 24,
                            maxRadius: width / 24,
                            backgroundColor: CustomColors.boxColourWithOpacity,
                            foregroundColor: CustomColors.boxColourWithOpacity,
                            backgroundImage: CachedNetworkImageProvider(
                              snapshot.data.toString(),
                            ),
                          ),
                          onPressed: () => {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => StudentProfileScreen(
                                          student: currStudent!,
                                        ))),
                          },
                        );
                      } else if (snapshot.hasError) {
                        return Icon(Icons.image_not_supported_sharp);
                      } else {
                        return CircleAvatar(
                          radius: width / 24,
                          backgroundColor: CustomColors.boxColourWithOpacity,
                          foregroundColor: CustomColors.boxColourWithOpacity,
                          // child: CircularProgressIndicator(),
                        );
                      }
                    },
                  ),
                  SizedBox(
                    width: width * 0.01,
                  ),
                ],
                bottom: TabBar(
                  indicatorColor: CustomColors.primaryColor,
                  //  controller: _tabController,
                  tabs: <Tab>[
                    Tab(
                      child: Text("List of Tuitions",
                          style: TextStyle(color: CustomColors.primaryColor)),
                    ),
                    Tab(
                      child: Text("Tuitions on Map",
                          style: TextStyle(color: CustomColors.primaryColor)),
                    ),
                  ],
                ),
                centerTitle: true,
              ),
              body: Material(
                  color: CustomColors.secondaryColor,
                  child: Container(
                      child: TabBarView(
                    children: [
                      Container(
                        height: height,
                        child: ListView.builder(
                          itemCount: tuitions.length,
                          itemBuilder: (BuildContext context, int index) {
                            return TuitionCardForStudents(tuitions[index],
                                currStudent, widget.userLocation);
                          },
                        ),
                      ),
                      Container(
                        width: width * 0.9,
                        height: height * 0.7,
                        padding: EdgeInsets.all(12),
                        child: FlutterMap(
                          options: MapOptions(
                            center: LatLng(21.1458, 79.0882),
                            zoom: 5.0,
                          ),
                          layers: [
                            TileLayerOptions(
                              urlTemplate:
                                  "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                              subdomains: ['a', 'b', 'c'],
                            ),
                            MarkerLayerOptions(
                              markers: allMarkers,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ))),
            ),
          );
    // : Scaffold(
    //     body: SingleChildScrollView(
    //         child: Container(
    //             color: CustomColors.secondaryColor,
    //             height: height,
    //             child: Column(
    //               mainAxisAlignment: MainAxisAlignment.start,
    //               crossAxisAlignment: CrossAxisAlignment.start,
    //               children: [
    //                 SizedBox(
    //                   height: height / 15,
    //                 ),
    //                 Padding(
    //                   padding: const EdgeInsets.all(10.0),
    //                   child: Row(
    //                     mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    //                     children: [
    //                       InkWell(
    //                         onTap: () {
    //                           Navigator.pop(context);
    //                         },
    //                         child: AnimatedContainer(
    //                           duration: Duration(seconds: 1),
    //                           width: width / 8,
    //                           height: height / 18,
    //                           child: Icon(
    //                             Icons.arrow_back,
    //                             color: CustomColors.buttonColor,
    //                           ),
    //                           decoration: BoxDecoration(
    //                             color: Colors.white70,
    //                             borderRadius: BorderRadius.circular(8),
    //                           ),
    //                         ),
    //                       ),
    //                       Padding(
    //                         padding: const EdgeInsets.only(left: 10),
    //                         child: Container(
    //                             child: Text(
    //                           "Hello ${currStudent!.studentName}",
    //                           style: TextStyle(
    //                               overflow: TextOverflow.clip,
    //                               fontSize: height / 40,
    //                               color: CustomColors.textColor),
    //                         )),
    //                       ),
    // FutureBuilder(
    //   future: Provider.of<Students>(context,
    //           listen: false)
    //       .getImageUrl(currStudent!.uid.toString()),
    //   builder: (context, snapshot) {
    //     if (snapshot.hasData) {
    //       return IconButton(
    //         icon: CircleAvatar(
    //           // minRadius: width / 8,
    //           // maxRadius: width / 8,
    //           minRadius: width / 24,
    //           maxRadius: width / 24,
    //           backgroundColor:
    //               CustomColors.boxColourWithOpacity,
    //           foregroundColor:
    //               CustomColors.boxColourWithOpacity,
    //           backgroundImage:
    //               CachedNetworkImageProvider(
    //             snapshot.data.toString(),
    //           ),
    //         ),
    //         onPressed: () => {
    //           Navigator.push(
    //               context,
    //               MaterialPageRoute(
    //                   builder: (context) =>
    //                       StudentProfileScreen(
    //                         student: currStudent!,
    //                       ))),
    //         },
    //       );
    //     } else if (snapshot.hasError) {
    //       return Icon(
    //           Icons.image_not_supported_sharp);
    //     } else {
    //       return CircleAvatar(
    //         radius: width / 15,
    //         backgroundColor:
    //             CustomColors.boxColourWithOpacity,
    //         foregroundColor:
    //             CustomColors.boxColourWithOpacity,
    //         // child: CircularProgressIndicator(),
    //       );
    //     }
    //   },
    // ),
    //                     ],
    //                   ),
    //                 ),
    //                 SizedBox(height: height / 50),
    //                 Padding(
    //                   padding: EdgeInsets.only(
    //                       left: width * .04,
    //                       right: width * .04,
    //                       top: height * .02,
    //                       bottom: height * .02),
    //                   child: Container(
    //                     padding: EdgeInsets.only(
    //                         left: width * .05, right: width * .05),
    //                     decoration: new BoxDecoration(
    //                         color:
    //                             CustomColors.primaryColor.withOpacity(.2),
    //                         borderRadius: new BorderRadius.all(
    //                             new Radius.circular(25.0))),
    //                     child: Row(
    //                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
    //                       crossAxisAlignment: CrossAxisAlignment.center,
    //                       children: <Widget>[
    //                         Padding(
    //                           padding:
    //                               new EdgeInsets.only(left: width * 0.0),
    //                           child: InkWell(
    //                             onTap: () {
    //                               msgToast(
    //                                   "search bar is available right now!");
    //                             },
    //                             child: new Icon(
    //                               Icons.search,
    //                               color: Colors.grey,
    //                               size: width * 0.06,
    //                             ),
    //                           ),
    //                         ),
    //                         SizedBox(
    //                           width: 20,
    //                         ),
    //                         Flexible(
    //                           child: TextFormField(
    //                             // focusNode: _searchingFocus,
    //                             textCapitalization:
    //                                 TextCapitalization.words,
    //                             controller: search,
    //                             obscureText: false,
    //                             // onFieldSubmitted: (term) {
    //                             //   _searchingFocus.unfocus();
    //                             // },
    //                             // controller: _isSearching,
    //                             decoration: InputDecoration(
    //                                 contentPadding: EdgeInsets.all(0.0),
    //                                 border: InputBorder.none,
    //                                 hintText: "Search Your Skills",
    //                                 hintStyle: new TextStyle(
    //                                   color: CustomColors.primaryColor,
    //                                   fontSize: 18,
    //                                 )),
    //                             // style: new TextStyle(
    //                             //     color: CommonColor.MENU_BTN_COLOR,
    //                             //     fontSize: categoryText - 3,
    //                             // fontFamily: CommonWidget.AVENIR_BOOK),
    //                           ),
    //                         ),
    //                         Padding(
    //                           padding:
    //                               new EdgeInsets.only(left: width * 0.0),
    //                           child: new Icon(
    //                             Icons.menu,
    //                             color: Colors.grey,
    //                             size: width * 0.06,
    //                           ),
    //                         ),
    //                       ],
    //                     ),
    //                   ),
    //                 ),
    //                 (tuitions.length == 0)
    //                     ? Container(
    //                         child: Column(
    //                             mainAxisAlignment: MainAxisAlignment.center,
    //                             crossAxisAlignment:
    //                                 CrossAxisAlignment.center,
    //                             children: [
    //                             SizedBox(
    //                               height: height / 10,
    //                             ),
    //                             Image(
    //                               image: AssetImage(
    //                                 "assets/images/sorry.gif",
    //                               ),
    //                               height: height * 0.3,
    //                             ),
    //                             SizedBox(
    //                               height: height / 10,
    //                             ),
    //                             Center(
    //                               child: Text(
    //                                 "We are not connected to Your area yet!\n\nTry in another nearby area!",
    //                                 style: TextStyle(
    //                                     color: CustomColors.primaryColor,
    //                                     fontSize: 17,
    //                                     fontWeight: FontWeight.bold),
    //                               ),
    //                             ),
    //                           ]))
    //                     : Container(
    //                         // color: Colors.red,
    //                         height: height * 0.7,
    //                         child: ListView.builder(
    //                           itemCount: tuitions.length,
    //                           itemBuilder:
    //                               (BuildContext context, int index) {
    //                             return TuitionCardForStudents(
    //                                 tuitions[index],
    //                                 currStudent,
    //                                 widget.userLocation);
    //                           },
    //                         ),
    //                       ),
    //               ],
    //             ))),
    //   );
  }
}
