import 'dart:io';
import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Models/student.dart';
import 'package:edurise/Provider/auth.dart';
import 'package:edurise/Provider/students.dart';
import 'package:edurise/Views/Additional/landing_page.dart';
import 'package:edurise/Views/Student/screens/search_tuition_page_for_students.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

class StudentProfileEditForm extends StatefulWidget {
  final Student? currentstudent;
  StudentProfileEditForm(this.currentstudent);
  @override
  _StudentProfileEditFormState createState() => _StudentProfileEditFormState();
}

class _StudentProfileEditFormState extends State<StudentProfileEditForm> {
  TextEditingController studentname = new TextEditingController();

  bool iskeyboardvisible = false;

  final _formKey = GlobalKey<FormState>();
  bool isEdit = false;

  String? uid;
  Student? newStudent;

  var _image;
  var imageUrl;
  var imagePicker;

  @override
  void initState() {
    super.initState();
    studentname.text = widget.currentstudent!.studentName.toString();

    isEdit = false;
  }

  uploadImage() async {
    final _firebaseStorage = FirebaseStorage.instance;
    final imagePicker = ImagePicker();

    await Permission.photos.request();
    var permissionStatus = await Permission.photos.status;

    if (permissionStatus.isGranted) {
      var image = await imagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 50,
      );
      setState(() {
        _image = File(image!.path);
      });
      uid = Provider.of<Auth>(context, listen: false)
          .firebaseUser!
          .uid
          .toString();
      if (_image != null) {
        var snapshot = await _firebaseStorage
            .ref()
            .child('StudentImages/$uid')
            .putFile(_image);
        var downloadUrl = await snapshot.ref.getDownloadURL();
        if (mounted) {
          setState(() {
            imageUrl = downloadUrl;
          });
        }
      } else {
       // print('No Image Path Received');
      }
    } else {
      // print('Permission not granted. Try Again with permission access');
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return
        //  isEdit
        //     ?
        Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Material(
        color: CustomColors.secondaryColor,
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                SizedBox(
                  height: height / 12,
                ),
                Row(
                  children: [
                    SizedBox(
                      width: width * 0.82,
                    ),
                    AnimatedContainer(
                      duration: Duration(seconds: 1),
                      width: height / 18,
                      height: height / 18,
                      child: Image.asset(
                        "assets/images/logo_transparent.png",
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: height / 30,
                ),
                Text(
                  "Update Your Profile",
                  style: TextStyle(
                    fontSize: height / 35,
                    fontWeight: FontWeight.bold,
                    color: CustomColors.textColor,
                  ),
                ),
                SizedBox(
                  height: height / 12,
                ),
                InkWell(
                  onTap: () async {
                    await uploadImage();
                  },
                  child: Container(
                    width: width / 3,
                    height: width / 3,
                    decoration: BoxDecoration(
                      color: Colors.red[200],
                    ),
                    child: _image != null
                        ? Image.file(
                            _image,
                            width: width / 3,
                            height: width / 3,
                            fit: BoxFit.fitHeight,
                          )
                        : Container(
                            decoration: BoxDecoration(color: Colors.red[200]),
                            width: width / 3,
                            height: width / 3,
                            child: Icon(
                              Icons.camera_alt,
                              color: Colors.grey[800],
                            ),
                          ),
                  ),
                ),
                SizedBox(
                  height: height / 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 35, right: 35),
                  child: TextFormField(
                    cursorColor: CustomColors.toyoPrimaryColor,
                    controller: studentname,
                    autocorrect: true,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                      color: CustomColors.toyoPrimaryColor,
                    ),
                    decoration: InputDecoration(
                      // hintText: "Ex: Lakshya JEE Classes",
                      labelText: "Student Name",
                      filled: true,
                      fillColor: CustomColors.secondaryColor,
                      labelStyle: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                          color: CustomColors.primaryColor),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: CustomColors.primaryColor,
                          width: 2.0,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: CustomColors.primaryColor,
                          width: 2.0,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Tuition must have a Name";
                      }
                      return null;
                    },
                  ),
                ),
                SizedBox(
                  height: height / 20,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () => {
                        setState(() {
                          isEdit = false;
                        })
                      },
                      child: AnimatedContainer(
                        duration: Duration(seconds: 1),
                        width: width / 2.9,
                        height: height / 17,
                        alignment: Alignment.center,
                        child: Text(
                          "Cancel",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: height / 45,
                          ),
                        ),
                        decoration: BoxDecoration(
                          color: CustomColors.buttonColor,
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: width / 10,
                    ),
                    InkWell(
                      onTap: () async => {
                        if (_formKey.currentState!.validate())
                          {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        StudentTuitionSearchPage())),
                            await Provider.of<Auth>(context, listen: false)
                                .getFirebaseUser(),
                            uid = Provider.of<Auth>(context, listen: false)
                                .firebaseUser!
                                .uid
                                .toString(),
                            newStudent = widget.currentstudent!.copyWith(
                              studentName: studentname.text.toString(),
                            ),

                            await Provider.of<Students>(context, listen: false)
                                .updateStudent(newStudent!),
                            // setState(() {
                            //   isEdit = false;
                            // })
                          }
                      },
                      child: AnimatedContainer(
                        duration: Duration(seconds: 1),
                        width: width / 2.9,
                        height: height / 17,
                        alignment: Alignment.center,
                        child: Text(
                          "Save",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: height / 45,
                          ),
                        ),
                        decoration: BoxDecoration(
                          color: CustomColors.buttonColor,
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: height / 15,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

showAlertDialog(BuildContext context) {
  // Create button
  Widget okButton = Row(
    children: [
      TextButton(
        child: Text("Yes"),
        onPressed: () async {
          await Provider.of<Auth>(context, listen: false).logout();

          Navigator.pushAndRemoveUntil(context,
              MaterialPageRoute(builder: (context) {
            return LandingPage();
          }), (route) => false);
        },
      ),
      TextButton(
        child: Text("No"),
        onPressed: () => Navigator.pop(context),
      )
    ],
  );

  // Create AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("Logout"),
    content: Text("Are you sure you want to Logout?"),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
