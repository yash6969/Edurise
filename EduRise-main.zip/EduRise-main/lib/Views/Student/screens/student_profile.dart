import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Models/student.dart';
import 'package:edurise/Provider/auth.dart';
import 'package:edurise/Views/Additional/landing_page.dart';
import 'package:edurise/Views/Student/screens/student_profile_edit.dart';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:edurise/Provider/students.dart';
import 'package:provider/provider.dart';

class StudentProfileScreen extends StatefulWidget {
  final Student student;

  StudentProfileScreen({Key? key, required this.student}) : super(key: key);

  @override
  State<StudentProfileScreen> createState() => _StudentProfileScreenState();
}

class _StudentProfileScreenState extends State<StudentProfileScreen> {
  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;

    return MaterialApp(
      home: Scaffold(
        backgroundColor: CustomColors.secondaryColor,
        body: SafeArea(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            FutureBuilder(
              future: Provider.of<Students>(context, listen: false)
                  .getImageUrl(widget.student.uid.toString()),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  return CircleAvatar(
                    radius: width / 6,
                    backgroundColor: CustomColors.boxColourWithOpacity,
                    foregroundColor: CustomColors.boxColourWithOpacity,
                    backgroundImage: CachedNetworkImageProvider(
                      snapshot.data.toString(),
                    ),
                  );
                } else {
                  return CircleAvatar(
                    radius: width / 6,
                    backgroundColor: CustomColors.boxColourWithOpacity,
                    foregroundColor: CustomColors.boxColourWithOpacity,
                    child: CircularProgressIndicator(),
                  );
                }
              },
            ),

            // CircleAvatar(
            //   radius: 50.0,
            //   backgroundImage: AssetImage('assets/nirala.jpeg'),
            // ),
            SizedBox(
              height: 20.0,
              width: 150.0,
//                  child: Divider(
//                    color: Colors.white,
//                  ),
            ),
            Text(
              widget.student.studentName,
              // args.user_name,
              style: TextStyle(
                fontFamily: 'Pacifico',
                fontSize: 30.0,
                color: CustomColors.primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(
              height: 10.0,
              width: 150.0,
//                  child: Divider(
//                    color: Colors.white,
//                  ),
            ),

            SizedBox(
              height: 20.0,
              width: 150.0,
              child: Divider(
                color: Colors.white,
              ),
            ),
            // Card(
            //   shape: RoundedRectangleBorder(
            //     borderRadius: BorderRadius.circular(25.0),
            //   ),
            //   color: Color(0xff373737),
            //   margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
            //   child: ListTile(
            //     // onTap: () {
            //     //   Navigator.push(
            //     //       context,
            //     //       MaterialPageRoute(
            //     //           builder: (context) => OrderHistoryPage()));
            //     // },
            //     leading: Icon(
            //       Icons.history,
            //       color: Colors.white,
            //     ),
            //     title: Text(
            //       'Your orders',
            //       style: TextStyle(
            //         color: Colors.white,
            //         fontFamily: 'Source Sans Pro',
            //         fontSize: 17.0,
            //       ),
            //     ),
            //     trailing: Icon(
            //       Icons.arrow_forward_ios_rounded,
            //       color: Colors.white,
            //     ),
            //   ),
            // ),
            Card(
              color: CustomColors.boxColourWithOpacity,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25.0),
              ),
              margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
              child: ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              StudentProfileEditForm(widget.student)));
                },
                leading: Icon(
                  Icons.edit,
                  color: Colors.white,
                ),
                title: Text(
                  'Edit details',
                  style: TextStyle(
                      fontSize: 17.0,
                      color: Colors.white,
                      fontFamily: 'Source Sans Pro'),
                ),
                trailing: Icon(
                  Icons.arrow_forward_ios_rounded,
                  color: Colors.white,
                ),
              ),
            ),
            Card(
              color: CustomColors.boxColourWithOpacity,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25.0),
              ),
              margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
              child: ListTile(
                onTap: () {
                  showAlertDialog(context);
                },
                leading: Icon(
                  Icons.logout,
                  color: Colors.white,
                ),
                title: Text(
                  'Logout',
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Source Sans Pro',
                    fontSize: 17.0,
                  ),
                ),
                trailing: Icon(
                  Icons.arrow_forward_ios_rounded,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        )),
      ),
    );
  }
}

showAlertDialog(BuildContext context) {
  // Create button
  Widget okButton = Row(
    children: [
      TextButton(
        child: Text("Yes"),
        onPressed: () async {
          await Provider.of<Auth>(context, listen: false).logout();

          Navigator.pushAndRemoveUntil(context,
              MaterialPageRoute(builder: (context) {
            return LandingPage();
          }), (route) => false);
        },
      ),
      TextButton(
        child: Text("No"),
        onPressed: () => Navigator.pop(context),
      )
    ],
  );

  // Create AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("Logout"),
    content: Text("Are you sure you want to Logout?"),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
