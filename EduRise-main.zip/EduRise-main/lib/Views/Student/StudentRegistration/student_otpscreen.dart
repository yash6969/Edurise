import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Provider/auth.dart';
import 'package:edurise/Views/Additional/landing_page.dart';
import 'package:edurise/Views/Additional/loading_screen.dart';
import 'package:edurise/Views/Student/StudentRegistration/student_registrtion_form.dart';
import 'package:edurise/Views/Student/screens/search_tuition_page_for_students.dart';
import 'package:edurise/Views/Student/StudentRegistration/student_login.dart';
import 'package:edurise/Views/widgets/msg_toast.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class StudentOtpScreen extends StatefulWidget {
  static const routeName = '/student-otp-screen';

  @override
  _StudentOtpScreenState createState() => _StudentOtpScreenState();
}

class _StudentOtpScreenState extends State<StudentOtpScreen> {
  bool? islogintrue;

  TextEditingController otpController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  bool isLoading = false;
  var isstudent;
  var istuition;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return isLoading
        ? LoadingScreen()
        : Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            child: Material(
              color: CustomColors.secondaryColor,
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      SizedBox(
                        height: height / 15,
                      ),
                      Row(
                        children: [
                          SizedBox(
                            width: width / 20,
                          ),
                          InkWell(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => StudentLoginPage()),
                              );
                            },
                            child: AnimatedContainer(
                              duration: Duration(seconds: 1),
                              width: height / 18,
                              height: height / 18,
                              child: Icon(
                                Icons.arrow_back,
                                color: CustomColors.buttonColor,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white70,
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: height / 10,
                      ),
                      Text(
                        "OTP has been sent to your number",
                        style: TextStyle(
                          fontSize: height / 40,
                          fontWeight: FontWeight.bold,
                          color: CustomColors.textColor,
                        ),
                      ),
                      SizedBox(
                        height: height / 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 35, right: 35),
                        child: TextFormField(
                          cursorColor: CustomColors.toyoPrimaryColor,
                          controller: otpController,
                          autocorrect: true,
                          keyboardType: TextInputType.number,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: CustomColors.toyoPrimaryColor,
                          ),
                          decoration: InputDecoration(
                            hintText: "Enter OTP",
                            labelText: "Enter OTP",
                            filled: true,
                            fillColor: CustomColors.secondaryColor,
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                color: CustomColors.primaryColor),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: BorderSide(
                                color: CustomColors.primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: height / 15,
                      ),
                      InkWell(
                        onTap: () async => {
                          setState(() {
                            isLoading = true;
                          }),
                          islogintrue =
                              await Provider.of<Auth>(context, listen: false)
                                  .submitOTP(otpController.text.toString()),
                          Auth.setUid(),
                         // print(Auth.uid),
                          istuition = await FirebaseFirestore.instance
                              .collection('Tuition')
                              .doc(Auth.uid)
                              .get(),
                          isstudent = await FirebaseFirestore.instance
                              .collection('Student')
                              .doc(Auth.uid)
                              .get(),
                          if (islogintrue == true)
                            {
                              if (istuition.exists)
                                {
                                  msgToast(
                                      "user already exists as tuition, please try using another number"),
                                  await Provider.of<Auth>(context,
                                          listen: false)
                                      .logout(),
                                  Navigator.pushAndRemoveUntil(context,
                                      MaterialPageRoute(builder: (context) {
                                    return LandingPage();
                                  }), (route) => false),
                                }
                              else if (isstudent.exists)
                                {
                                  Navigator.pushAndRemoveUntil(context,
                                      MaterialPageRoute(builder: (context) {
                                    return StudentTuitionSearchPage();
                                    // StudentDashBoard();
                                  }), (route) => false),
                                }
                              else
                                {
                                  Navigator.pushAndRemoveUntil(context,
                                      MaterialPageRoute(builder: (context) {
                                    return StudentRegistrationForm();
                                  }), (route) => false),
                                }
                            }
                          else
                            {
                              Navigator.pushAndRemoveUntil(context,
                                  MaterialPageRoute(builder: (context) {
                                return StudentLoginPage();
                              }), (route) => false),
                            }
                        },
                        child: AnimatedContainer(
                          duration: Duration(seconds: 1),
                          width: width / 1.8,
                          height: height / 16,
                          alignment: Alignment.center,
                          child: Text(
                            "Submit OTP",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: height / 45,
                            ),
                          ),
                          decoration: BoxDecoration(
                            color: CustomColors.buttonColor,
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                      ),
                      SizedBox(height: height / 15)
                    ],
                  ),
                ),
              ),
            ),
          );
  }
}
