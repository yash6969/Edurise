import 'package:cached_network_image/cached_network_image.dart';
import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Models/tuition.dart';
import 'package:edurise/Provider/tuitions.dart';
import 'package:edurise/Views/Guest/screens/tuition_deatils_page_for_guests.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class TuitionCardForGuest extends StatefulWidget {
  final Tuition? tuition;
  final Map<String, String> userLocation;
  TuitionCardForGuest(this.tuition, this.userLocation);

  @override
  State<TuitionCardForGuest> createState() => _TuitionCardForGuestState();
}

class _TuitionCardForGuestState extends State<TuitionCardForGuest> {
  bool isLoading = true;
  @override
  Future<void> didChangeDependencies() async {
    int? reachOFTuition = widget.tuition!.reach;
    reachOFTuition = reachOFTuition! + 1;
    Tuition newTuition = widget.tuition!.copyWith(reach: reachOFTuition);
    await Provider.of<Tuitions>(context, listen: false)
        .fetchAndSetTuitions()
        .then((value) => Provider.of<Tuitions>(context, listen: false)
            .updateTuition(newTuition));

    Map<String, String>? map = widget.tuition!.usersLocations;
    map!.putIfAbsent(widget.userLocation.keys.toString(),
        () => widget.userLocation.values.toString());
    map.update(widget.userLocation.keys.toString(),
        (value) => widget.userLocation.values.toString());
    Tuition t = widget.tuition!.copyWith(
      usersLocations: map,
    );
    if (mounted)
      await Provider.of<Tuitions>(context, listen: false).updateTuition(t);
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) =>
                  TuitionDetailsPageForGuests(widget.tuition)),
        );
      },
      child: Container(
        width: width,
        height: height / 5,
        padding: new EdgeInsets.all(10.0),
        child: Card(
          shape: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(20))),
          color: CustomColors.boxColourWithOpacity,
          margin: EdgeInsets.only(left: 15, right: 15, top: 10, bottom: 0),
          child: Center(
            child: ListTile(
              leading: FutureBuilder(
                future: Provider.of<Tuitions>(context, listen: false)
                    .getImageUrl(widget.tuition!.uid.toString()),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return CircleAvatar(
                      minRadius: width / 8,
                      maxRadius: width / 8,
                      backgroundColor: CustomColors.boxColourWithOpacity,
                      foregroundColor: CustomColors.boxColourWithOpacity,
                      backgroundImage: CachedNetworkImageProvider(
                        snapshot.data.toString(),
                      ),
                    );
                  } else if (snapshot.hasError) {
                    return Icon(Icons.image_not_supported_sharp);
                  } else {
                    return CircleAvatar(
                      radius: width / 8,
                      backgroundColor: CustomColors.boxColourWithOpacity,
                      foregroundColor: CustomColors.boxColourWithOpacity,
                      child: CircularProgressIndicator(),
                    );
                  }
                },
              ),
              isThreeLine: true,
              horizontalTitleGap: 2,
              minLeadingWidth: width / 8,
              title: Text(
                widget.tuition!.tuitionName,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(widget.tuition!.address,
                    style: TextStyle(fontWeight: FontWeight.w500)),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
