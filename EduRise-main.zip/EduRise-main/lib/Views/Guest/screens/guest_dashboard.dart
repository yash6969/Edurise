// import 'package:edurise/Constants/app_theme.dart';
// import 'package:edurise/Models/tuition.dart';
// import 'package:edurise/Provider/tuitions.dart';
// import 'package:edurise/Views/Additional/loading_screen.dart';
// import 'package:edurise/Views/widgets/msg_toast.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_map/flutter_map.dart';
// import 'package:latlong2/latlong.dart';
// import 'package:provider/provider.dart';
// import 'search_tuition_page.dart';

// class GuestDashBoard extends StatefulWidget {
//   String pincode;
//   List<Marker> allMarkers = [];
//   Map<String, String> userLocation;
//   GuestDashBoard(this.pincode, this.userLocation);

//   @override
//   State<GuestDashBoard> createState() => _GuestDashBoardState();
// }

// class _GuestDashBoardState extends State<GuestDashBoard>
//     with SingleTickerProviderStateMixin {
//   List<Tuition> tuitions = [];
//   List<Marker> allMarkers = [];
//   TextEditingController search = TextEditingController();

//   bool _isInit = true;
//   bool isLoading = true;

//   @override
//   Future<void> didChangeDependencies() async {
//     super.didChangeDependencies();
//     if (_isInit) {
//       await Provider.of<Tuitions>(context, listen: false)
//           .fetchAndSetTuitionswithPincode(widget.pincode.toString())
//           .then((value) => setState(() {
//                 tuitions = Provider.of<Tuitions>(context, listen: false)
//                     .tuitionsWithPincode;
//               }));
//       // print(tuitions);

//       tuitions.forEach((element) {
//         element.tuitionLocation!.forEach((key, value) {
//           double lat = double.parse(key);
//           double long = double.parse(value);

//           print("$lat $long");

//           allMarkers.add(
//             Marker(
//               point: LatLng(lat, long),
//               builder: (context) => const Icon(
//                 Icons.circle,
//                 color: Colors.red,
//                 size: 12.0,
//               ),
//             ),
//           );
//         });
//       });

//       print(allMarkers);
//       setState(() {
//         isLoading = false;
//       });
//     }
//     _isInit = false;
//   }

//   @override
//   Widget build(BuildContext context) {
//     final width = MediaQuery.of(context).size.width;
//     final height = MediaQuery.of(context).size.height;
//     return isLoading
//         ? LoadingScreen()
//         : Scaffold(
//             body: SingleChildScrollView(
//                 child: Container(
//                     color: CustomColors.secondaryColor,
//                     height: height,
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.start,
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         SizedBox(
//                           height: height / 15,
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.all(10.0),
//                           child: Row(
//                             children: [
//                               InkWell(
//                                 onTap: () {
//                                   Navigator.push(
//                                     context,
//                                     MaterialPageRoute(
//                                         builder: (context) =>
//                                             SearchTuitionPage()),
//                                   );
//                                 },
//                                 child: AnimatedContainer(
//                                   duration: Duration(seconds: 1),
//                                   width: height / 18,
//                                   height: height / 18,
//                                   child: Icon(
//                                     Icons.arrow_back,
//                                     color: CustomColors.buttonColor,
//                                   ),
//                                   decoration: BoxDecoration(
//                                     color: Colors.white70,
//                                     borderRadius: BorderRadius.circular(8),
//                                   ),
//                                 ),
//                               ),
//                               Padding(
//                                 padding: const EdgeInsets.only(left: 80),
//                                 child: Container(
//                                     child: Text(
//                                   "Hello Guest !!",
//                                   style: TextStyle(
//                                       fontSize: 22,
//                                       color: CustomColors.textColor),
//                                 )),
//                               )
//                             ],
//                           ),
//                         ),
//                         SizedBox(height: height / 50),
//                         Padding(
//                           padding: EdgeInsets.only(
//                               left: width * .04,
//                               right: width * .04,
//                               top: height * .02,
//                               bottom: height * .02),
//                           child: Container(
//                             padding: EdgeInsets.only(
//                                 left: width * .05, right: width * .05),
//                             decoration: new BoxDecoration(
//                                 color:
//                                     CustomColors.primaryColor.withOpacity(.2),
//                                 borderRadius: new BorderRadius.all(
//                                     new Radius.circular(25.0))),
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               crossAxisAlignment: CrossAxisAlignment.center,
//                               children: <Widget>[
//                                 Padding(
//                                   padding:
//                                       new EdgeInsets.only(left: width * 0.0),
//                                   child: InkWell(
//                                     onTap: () {
//                                       msgToast(
//                                           "search bar is available right now!");
//                                     },
//                                     child: new Icon(
//                                       Icons.search,
//                                       color: Colors.grey,
//                                       size: width * 0.06,
//                                     ),
//                                   ),
//                                 ),
//                                 SizedBox(
//                                   width: 20,
//                                 ),
//                                 Flexible(
//                                   child: TextFormField(
//                                     // focusNode: _searchingFocus,
//                                     textCapitalization:
//                                         TextCapitalization.words,
//                                     controller: search,
//                                     obscureText: false,
//                                     // onFieldSubmitted: (term) {
//                                     //   _searchingFocus.unfocus();
//                                     // },
//                                     // controller: _isSearching,
//                                     decoration: InputDecoration(
//                                         contentPadding: EdgeInsets.all(0.0),
//                                         border: InputBorder.none,
//                                         hintText: "Search Your Skills",
//                                         hintStyle: new TextStyle(
//                                           color: CustomColors.primaryColor,
//                                           fontSize: 18,
//                                         )),
//                                     // style: new TextStyle(
//                                     //     color: CommonColor.MENU_BTN_COLOR,
//                                     //     fontSize: categoryText - 3,
//                                     // fontFamily: CommonWidget.AVENIR_BOOK),
//                                   ),
//                                 ),
//                                 Padding(
//                                   padding:
//                                       new EdgeInsets.only(left: width * 0.0),
//                                   child: new Icon(
//                                     Icons.menu,
//                                     color: Colors.grey,
//                                     size: width * 0.06,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ),
//                         // Container(

//                         //   // color: Colors.red,
//                         //   height: height - 220,
//                         //   child: ListView.builder(

//                         //     itemCount: tuitions.length,
//                         //     itemBuilder: (BuildContext context, int index) {
//                         //       return TuitionCard(tuitions[index]);
//                         //     },
//                         //   ),
//                         // ),
//                         (tuitions.length == 0)
//                             ? Container(
//                                 child: Column(
//                                     mainAxisAlignment: MainAxisAlignment.center,
//                                     crossAxisAlignment:
//                                         CrossAxisAlignment.center,
//                                     children: [
//                                     SizedBox(
//                                       height: height / 10,
//                                     ),
//                                     Image(
//                                       image: AssetImage(
//                                         "assets/images/sorry.gif",
//                                       ),
//                                       height: height * 0.3,
//                                     ),
//                                     SizedBox(
//                                       height: height / 10,
//                                     ),
//                                     Center(
//                                       child: Text(
//                                         "We are not connected to Your area yet!\n\nTry in another nearby area!",
//                                         style: TextStyle(
//                                             color: CustomColors.primaryColor,
//                                             fontSize: 17,
//                                             fontWeight: FontWeight.bold),
//                                       ),
//                                     ),
//                                   ]))
//                             : Stack(
//                                 children: [
//                                   Center(
//                                     child: Container(
//                                       width: width * 0.9,
//                                       height: height * 0.7,
//                                       child: FlutterMap(
//                                         options: MapOptions(
//                                           center: LatLng(28.644800, 77.216721),
//                                           zoom: 4.0,
//                                         ),
//                                         layers: [
//                                           TileLayerOptions(
//                                             urlTemplate:
//                                                 "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
//                                             subdomains: ['a', 'b', 'c'],
//                                           ),
//                                           MarkerLayerOptions(
//                                             markers: allMarkers,
//                                           ),
//                                         ],
//                                       ),
//                                     ),
//                                   ),

//                                   // SlidingUpPanel(
//                                   //   isDraggable: true,
//                                   //   minHeight: height * 0.15,
//                                   //   maxHeight: height * 0.7,
//                                   //   // backdropEnabled: true,

//                                   //   slideDirection: SlideDirection.DOWN,
//                                   //   panel: Center(
//                                   //     child: Text("This is the sliding Widget"),
//                                   //     // child: Container(
//                                   //     //   height: height * 0.7,
//                                   //       // child: ListView.builder(
//                                   //       //   itemCount: tuitions.length,
//                                   //       //   itemBuilder: (BuildContext context,
//                                   //       //       int index) {
//                                   //       //     return TuitionCardForGuest(
//                                   //       //         tuitions[index],
//                                   //       //         widget.userLocation);
//                                   //       //   },
//                                   //       // ),
//                                   //     // ),
//                                   //   ),
//                                   // )
//                                   // SlidingUpPanel(
//                                   //   isDraggable: true,
//                                   //   minHeight: height * 0.15,
//                                   //   maxHeight: height * 0.7,
//                                   //   slideDirection: SlideDirection.DOWN,
//                                   //   panel: Center(
//                                   //     child: Text("This is the sliding Widget"),
//                                   //     // child: Container(
//                                   //     //   height: height * 0.7,
//                                   //     //   child: ListView.builder(
//                                   //     //     itemCount: tuitions.length,
//                                   //     //     itemBuilder: (BuildContext context,
//                                   //     //         int index) {
//                                   //     //       return TuitionCardForGuest(
//                                   //     //           tuitions[index],
//                                   //     //           widget.userLocation);
//                                   //     //     },
//                                   //     //   ),
//                                   //     // ),
//                                   //   ),
//                                   // )

//                                   // Container(
//                                   //   height: height - 220,
//                                   //   child: ListView.builder(
//                                   //     itemCount: tuitions.length,
//                                   //     itemBuilder:
//                                   //         (BuildContext context, int index) {
//                                   //       return TuitionCardForGuest(
//                                   //           tuitions[index],
//                                   //           widget.userLocation);
//                                   //     },
//                                   //   ),
//                                   // ),
//                                 ],
//                               )
//                         // Container(
//                         //     height: height - 220,
//                         //     child: ListView.builder(
//                         //       itemCount: tuitions.length,
//                         //       itemBuilder:
//                         //           (BuildContext context, int index) {
//                         //         return TuitionCardForGuest(tuitions[index], widget.userLocation);
//                         //       },
//                         //     ),
//                         //   ),
//                       ],
//                     ))),
//           );
//   }
// }

import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Models/tuition.dart';
import 'package:edurise/Provider/tuitions.dart';
import 'package:edurise/Views/Additional/loading_screen.dart';
import 'package:edurise/Views/Guest/widgets/tuition_card_for_guests.dart';
import 'package:edurise/Views/widgets/msg_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import 'search_tuition_page.dart';

class GuestDashBoard extends StatefulWidget {
  final String pincode;
  final Map<String, String> userLocation;
  GuestDashBoard(this.pincode, this.userLocation);

  @override
  State<GuestDashBoard> createState() => _GuestDashBoardState();
}

class _GuestDashBoardState extends State<GuestDashBoard>
    with SingleTickerProviderStateMixin {
  List<Tuition> tuitions = [];
  List<Marker> allMarkers = [];
  TextEditingController search = TextEditingController();

  bool _isInit = true;
  bool isLoading = true;

  @override
  Future<void> didChangeDependencies() async {
    super.didChangeDependencies();
    if (_isInit) {
      await Provider.of<Tuitions>(context, listen: false)
          .fetchAndSetTuitionswithPincode(widget.pincode.toString())
          .then((value) => setState(() {
                tuitions = Provider.of<Tuitions>(context, listen: false)
                    .tuitionsWithPincode;
              }));
      // print(tuitions);

      tuitions.forEach((element) {
        element.tuitionLocation!.forEach((key, value) {
          double lat = double.parse(key);
          double long = double.parse(value);

          // print("$lat $long");

          allMarkers.add(
            Marker(
              point: LatLng(lat, long),
              builder: (context) => const Icon(
                Icons.circle,
                color: Colors.red,
                size: 12.0,
              ),
            ),
          );
        });
      });

      //print(allMarkers);
      setState(() {
        isLoading = false;
      });
    }
    _isInit = false;
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return isLoading
        ? LoadingScreen()
        : DefaultTabController(
            length: 2,
            child: Scaffold(
              appBar: AppBar(
                foregroundColor: CustomColors.primaryColor,
                backgroundColor: CustomColors.secondaryColor,
                title: Text(
                  "Hey there!",
                  style: TextStyle(color: CustomColors.primaryColor),
                ),
                actions: [
                  Icon(Icons.dashboard_customize),
                  SizedBox(
                    width: width * 0.05,
                  ),
                ],
                bottom: TabBar(
                  indicatorColor: CustomColors.primaryColor,
                  //  controller: _tabController,
                  tabs: <Tab>[
                    Tab(
                      child: Text("List of Tuitions",
                          style: TextStyle(color: CustomColors.primaryColor)),
                    ),
                    Tab(
                      child: Text("Tuitions on Map",
                          style: TextStyle(color: CustomColors.primaryColor)),
                    ),
                  ],
                ),
                centerTitle: true,
              ),
              body: Material(
                  color: CustomColors.secondaryColor,
                  child: Container(
                      child: TabBarView(
                    children: [
                      Container(
                        height: height,
                        child: ListView.builder(
                          itemCount: tuitions.length,
                          itemBuilder: (BuildContext context, int index) {
                            return TuitionCardForGuest(
                                tuitions[index], widget.userLocation);
                          },
                        ),
                      ),
                      Container(
                        width: width * 0.9,
                        height: height * 0.7,
                        padding: EdgeInsets.all(12),
                        child: FlutterMap(
                          options: MapOptions(
                            center: LatLng(21.1458, 79.0882),
                            zoom: 5.0,
                          ),
                          layers: [
                            TileLayerOptions(
                              urlTemplate:
                                  "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                              subdomains: ['a', 'b', 'c'],
                            ),
                            MarkerLayerOptions(
                              markers: allMarkers,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ))),

              // body: SingleChildScrollView(
              //     child: Container(
              //         color: CustomColors.secondaryColor,
              //         height: height,
              //         child: Column(
              //           mainAxisAlignment: MainAxisAlignment.start,
              //           crossAxisAlignment: CrossAxisAlignment.start,
              //           children: [
              //             SizedBox(
              //               height: height / 15,
              //             ),
              //             Padding(
              //               padding: const EdgeInsets.all(10.0),
              //               child: Row(
              //                 children: [
              //                   InkWell(
              //                     onTap: () {
              //                       Navigator.push(
              //                         context,
              //                         MaterialPageRoute(
              //                             builder: (context) =>
              //                                 SearchTuitionPage()),
              //                       );
              //                     },
              //                     child: AnimatedContainer(
              //                       duration: Duration(seconds: 1),
              //                       width: height / 18,
              //                       height: height / 18,
              //                       child: Icon(
              //                         Icons.arrow_back,
              //                         color: CustomColors.buttonColor,
              //                       ),
              //                       decoration: BoxDecoration(
              //                         color: Colors.white70,
              //                         borderRadius: BorderRadius.circular(8),
              //                       ),
              //                     ),
              //                   ),
              //                   Padding(
              //                     padding: const EdgeInsets.only(left: 80),
              //                     child: Container(
              //                         child: Text(
              //                       "Hello Guest !!",
              //                       style: TextStyle(
              //                           fontSize: 22,
              //                           color: CustomColors.textColor),
              //                     )),
              //                   )
              //                 ],
              //               ),
              //             ),
              //             SizedBox(height: height / 50),
              //             Padding(
              //               padding: EdgeInsets.only(
              //                   left: width * .04,
              //                   right: width * .04,
              //                   top: height * .02,
              //                   bottom: height * .02),
              //               child: Container(
              //                 padding: EdgeInsets.only(
              //                     left: width * .05, right: width * .05),
              //                 decoration: new BoxDecoration(
              //                     color:
              //                         CustomColors.primaryColor.withOpacity(.2),
              //                     borderRadius: new BorderRadius.all(
              //                         new Radius.circular(25.0))),
              //                 child: Row(
              //                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //                   crossAxisAlignment: CrossAxisAlignment.center,
              //                   children: <Widget>[
              //                     Padding(
              //                       padding:
              //                           new EdgeInsets.only(left: width * 0.0),
              //                       child: InkWell(
              //                         onTap: () {
              //                           msgToast(
              //                               "search bar is available right now!");
              //                         },
              //                         child: new Icon(
              //                           Icons.search,
              //                           color: Colors.grey,
              //                           size: width * 0.06,
              //                         ),
              //                       ),
              //                     ),
              //                     SizedBox(
              //                       width: 20,
              //                     ),
              //                     Flexible(
              //                       child: TextFormField(
              //                         // focusNode: _searchingFocus,
              //                         textCapitalization:
              //                             TextCapitalization.words,
              //                         controller: search,
              //                         obscureText: false,
              //                         // onFieldSubmitted: (term) {
              //                         //   _searchingFocus.unfocus();
              //                         // },
              //                         // controller: _isSearching,
              //                         decoration: InputDecoration(
              //                             contentPadding: EdgeInsets.all(0.0),
              //                             border: InputBorder.none,
              //                             hintText: "Search Your Skills",
              //                             hintStyle: new TextStyle(
              //                               color: CustomColors.primaryColor,
              //                               fontSize: 18,
              //                             )),
              //                         // style: new TextStyle(
              //                         //     color: CommonColor.MENU_BTN_COLOR,
              //                         //     fontSize: categoryText - 3,
              //                         // fontFamily: CommonWidget.AVENIR_BOOK),
              //                       ),
              //                     ),
              //                     Padding(
              //                       padding:
              //                           new EdgeInsets.only(left: width * 0.0),
              //                       child: new Icon(
              //                         Icons.menu,
              //                         color: Colors.grey,
              //                         size: width * 0.06,
              //                       ),
              //                     ),
              //                   ],
              //                 ),
              //               ),
              //             ),
              //             // Container(

              //             //   // color: Colors.red,
              //             //   height: height - 220,
              //             //   child: ListView.builder(

              //             //     itemCount: tuitions.length,
              //             //     itemBuilder: (BuildContext context, int index) {
              //             //       return TuitionCard(tuitions[index]);
              //             //     },
              //             //   ),
              //             // ),
              //             (tuitions.length == 0)
              //                 ? Container(
              //                     child: Column(
              //                         mainAxisAlignment: MainAxisAlignment.center,
              //                         crossAxisAlignment:
              //                             CrossAxisAlignment.center,
              //                         children: [
              //                         SizedBox(
              //                           height: height / 10,
              //                         ),
              //                         Image(
              //                           image: AssetImage(
              //                             "assets/images/sorry.gif",
              //                           ),
              //                           height: height * 0.3,
              //                         ),
              //                         SizedBox(
              //                           height: height / 10,
              //                         ),
              //                         Center(
              //                           child: Text(
              //                             "We are not connected to Your area yet!\n\nTry in another nearby area!",
              //                             style: TextStyle(
              //                                 color: CustomColors.primaryColor,
              //                                 fontSize: 17,
              //                                 fontWeight: FontWeight.bold),
              //                           ),
              //                         ),
              //                       ]))
              //                 : Stack(
              //                     children: [
              //                       Center(
              // child: Container(
              //   width: width * 0.9,
              //   height: height * 0.7,
              //   child: FlutterMap(
              //     options: MapOptions(
              //       center: LatLng(28.644800, 77.216721),
              //       zoom: 4.0,
              //     ),
              //     layers: [
              //       TileLayerOptions(
              //         urlTemplate:
              //             "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
              //         subdomains: ['a', 'b', 'c'],
              //       ),
              //       MarkerLayerOptions(
              //         markers: allMarkers,
              //       ),
              //     ],
              //   ),
              // ),
              //                       ),

              //                       // SlidingUpPanel(
              //                       //   isDraggable: true,
              //                       //   minHeight: height * 0.15,
              //                       //   maxHeight: height * 0.7,
              //                       //   // backdropEnabled: true,

              //                       //   slideDirection: SlideDirection.DOWN,
              //                       //   panel: Center(
              //                       //     child: Text("This is the sliding Widget"),
              //                       //     // child: Container(
              //                       //     //   height: height * 0.7,
              //                       //       // child: ListView.builder(
              //                       //       //   itemCount: tuitions.length,
              //                       //       //   itemBuilder: (BuildContext context,
              //                       //       //       int index) {
              //                       //       //     return TuitionCardForGuest(
              //                       //       //         tuitions[index],
              //                       //       //         widget.userLocation);
              //                       //       //   },
              //                       //       // ),
              //                       //     // ),
              //                       //   ),
              //                       // )
              //                       // SlidingUpPanel(
              //                       //   isDraggable: true,
              //                       //   minHeight: height * 0.15,
              //                       //   maxHeight: height * 0.7,
              //                       //   slideDirection: SlideDirection.DOWN,
              //                       //   panel: Center(
              //                       //     child: Text("This is the sliding Widget"),
              //                       //     // child: Container(
              //                       //     //   height: height * 0.7,
              //                       //     //   child: ListView.builder(
              //                       //     //     itemCount: tuitions.length,
              //                       //     //     itemBuilder: (BuildContext context,
              //                       //     //         int index) {
              //                       //     //       return TuitionCardForGuest(
              //                       //     //           tuitions[index],
              //                       //     //           widget.userLocation);
              //                       //     //     },
              //                       //     //   ),
              //                       //     // ),
              //                       //   ),
              //                       // )

              //                       // Container(
              //                       //   height: height - 220,
              //                       //   child: ListView.builder(
              //                       //     itemCount: tuitions.length,
              //                       //     itemBuilder:
              //                       //         (BuildContext context, int index) {
              //                       //       return TuitionCardForGuest(
              //                       //           tuitions[index],
              //                       //           widget.userLocation);
              //                       //     },
              //                       //   ),
              //                       // ),
              //                     ],
              //                   )
              // Container(
              //     height: height - 220,
              //     child: ListView.builder(
              //       itemCount: tuitions.length,
              //       itemBuilder:
              //           (BuildContext context, int index) {
              //         return TuitionCardForGuest(tuitions[index], widget.userLocation);
              //       },
              //     ),
              //   ),
              //           ],
              //         ))),
            ),
          );
  }
}
