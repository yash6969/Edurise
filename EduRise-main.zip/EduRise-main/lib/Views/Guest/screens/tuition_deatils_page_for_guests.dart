import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Models/faculty.dart';
import 'package:edurise/Models/student.dart';
import 'package:edurise/Models/tuition.dart';
import 'package:edurise/Provider/students.dart';
import 'package:edurise/Provider/tuitions.dart';
import 'package:edurise/Views/widgets/msg_toast.dart';
import 'package:edurise/Views/widgets/review_card.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:badges/badges.dart';

class TuitionDetailsPageForGuests extends StatefulWidget {
  final Tuition? tuition;
  TuitionDetailsPageForGuests(this.tuition);

  @override
  State<TuitionDetailsPageForGuests> createState() =>
      _TuitionDetailsPageForGuestsState();
}

class _TuitionDetailsPageForGuestsState
    extends State<TuitionDetailsPageForGuests> {
  bool showReview = false;
  List<Map<String, String>> reviews = [];
  Student? reviewer;
  String? reviewerName;

  Future<void> didChangeDependencies() async {
    int? viewsOfTuition = widget.tuition!.views;
    viewsOfTuition = viewsOfTuition! + 1;
    Tuition newTuition = widget.tuition!.copyWith(views: viewsOfTuition);
    await Provider.of<Tuitions>(context, listen: false)
        .fetchAndSetTuitions()
        .then((value) => Provider.of<Tuitions>(context, listen: false)
            .updateTuition(newTuition));

    widget.tuition!.reviews!.forEach((key, value) async {
      await Provider.of<Students>(context, listen: false)
          .fetchAndSetStudents()
          .then((value) => reviewer =
              Provider.of<Students>(context, listen: false).getStudent(key));
      reviewerName = reviewer!.studentName;
      Map<String, String> m = {reviewerName!: value};
      reviews.add(m);
    });
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
        backgroundColor: CustomColors.secondaryColor,
        body: SingleChildScrollView(
          child: Container(
            color: CustomColors.secondaryColor,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Badge(
                  position: BadgePosition(bottom: -25),
                  badgeColor: Colors.white,
                  toAnimate: false,
                  shape: BadgeShape.square,
                  borderRadius: BorderRadius.all(Radius.circular(50)),
                  badgeContent: Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(20))),
                    height: height / 23,
                    width: width / 3.5,
                    child: Center(
                        child: InkWell(
                            onTap: () {
                             // print("enroll service");
                              msgToast("Service not available right Now!");
                            },
                            child: Text("Enroll",
                                style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black)))),
                  ),
                  child: Container(
                    height: height / 3,
                    width: width,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage('assets/images/institute.png')),
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(20),
                          bottomRight: Radius.circular(20)),
                      color: CustomColors.primaryColor,
                    ),
                    child: Stack(
                      children: [
                        Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                widget.tuition!.tuitionName,
                                style: TextStyle(
                                    fontSize: 30,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: height * 0.05,
                ),
                Container(
                  // height: height,
                  width: width,

                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Text("About us",
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 100,
                        ),
                        Text(widget.tuition!.tuitionDescription,
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.normal,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 20,
                        ),

                        Text("Our Previous Achievements",
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 100,
                        ),
                        Text(widget.tuition!.achievements,
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.normal,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 20,
                        ),

                        ///
                        ////
                        ///
                        Text("Address",
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 100,
                        ),
                        Text(
                            widget.tuition!.address +
                                ", Pincode: " +
                                widget.tuition!.pincode,
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.normal,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 20,
                        ),
                        ////
                        /////
                        ///
                        Text("Which class can Enroll",
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 100,
                        ),
                        Text(widget.tuition!.classes,
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.normal,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 20,
                        ),

                        ///
                        ///
                        ///
                        Text("Subjects",
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 100,
                        ),
                        Text(widget.tuition!.subjects,
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.normal,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 20,
                        ),

                        ///
                        ///
                        ///
                        Text("Tuition Fee Details",
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 100,
                        ),
                        Text(widget.tuition!.fee,
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.normal,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 20,
                        ),

                        ///
                        ///
                        ///
                        Text("Mode of Teaching: ",
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 100,
                        ),
                        Text(widget.tuition!.modeOfTeaching,
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.normal,
                                color: Colors.black)),
                        SizedBox(
                          height: height / 20,
                        ),
                        Text("Gallery",
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.black)),
                        //       SizedBox(
                        //   height: height / 20,
                        // ),
                        FutureBuilder(
                          future: Provider.of<Tuitions>(context, listen: false)
                              .getImageUrl(widget.tuition!.uid.toString()),
                          builder: (context, snapshot) {
                            if (snapshot.hasData) {
                              return Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: Container(
                                  // width: width,
                                  height: height / 3,
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: NetworkImage(
                                    snapshot.data.toString(),
                                  ))),
                                ),
                              );
                            } else if (snapshot.hasError) {
                              return Icon(Icons.image_not_supported_sharp);
                            } else {
                              return CircleAvatar(
                                radius: width / 8,
                                backgroundColor:
                                    CustomColors.boxColourWithOpacity,
                                foregroundColor:
                                    CustomColors.boxColourWithOpacity,
                                child: CircularProgressIndicator(),
                              );
                            }
                          },
                        ),
                        // SizedBox(
                        //   height: height / 20,
                        // ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                  color: CustomColors.primaryColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(30))),
                              height: height / 16,
                              width: width / 3,
                              child: Center(
                                  child: InkWell(
                                      onTap: () {
                                        msgToast(
                                            "Service not available right Now!");
                                      },
                                      child: Text("Enroll Now",
                                          style: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white)))),
                            ),
                            // SizedBox(
                            //   width: width / 10,
                            // ),
                            FloatingActionButton(
                              backgroundColor: Colors.green,
                              heroTag: "messageTag",
                              onPressed: () {
                                msgToast("please sign in as student");
                              },
                              child: Icon(Icons.message_outlined),
                            ),
                            FloatingActionButton(
                              backgroundColor: Colors.green,
                              heroTag: "callTag",
                              onPressed: () {
                                msgToast("please sign in as student");
                              },
                              child: Icon(Icons.call),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: height / 10,
                        ),
                        TextButton(
                          onPressed: () {
                            if (!showReview) {
                              setState(() {
                                showReview = true;
                              });
                            } else {
                              setState(() {
                                showReview = false;
                              });
                            }
                          },
                          child: Row(children: [
                            Text("See What people say about us ",
                                style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black)),
                            Icon(
                              Icons.arrow_drop_down_outlined,
                              color: Colors.black,
                            )
                          ]),
                        ),
                        SizedBox(
                          height: height / 100,
                        ),
                        showReview
                            ? (reviews.length == 0)
                                ? Column(
                                    children: [
                                      SizedBox(
                                        height: height * 0.05,
                                      ),
                                      Text("No Reviews yet",
                                          style: TextStyle(
                                              fontSize: 20,
                                              color: CustomColors.primaryColor,
                                              fontWeight: FontWeight.bold))
                                    ],
                                  )
                                : SingleChildScrollView(
                                    child: Container(
                                      width: width * 0.85,
                                      height: height * 0.65,
                                      child: ListView.builder(
                                        itemCount: reviews.length,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return ReviewCard(reviews[index]);
                                        },
                                      ),
                                    ),
                                  )
                            : SizedBox(),
                        SizedBox(
                          height: height / 10,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ));
  }

  Widget subjectCard(Faculty f) {
    return Container(
      height: 200,
      width: 200,
      color: Colors.red,
      child: Text("f.facultyName"),
    );
  }
}
