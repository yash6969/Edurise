import 'package:edurise/Views/Additional/loading_screen.dart';
import 'package:edurise/Views/Guest/screens/guest_dashboard.dart';
import 'package:edurise/Views/Additional/landing_page.dart';
import 'package:edurise/Constants/app_theme.dart';
import 'package:edurise/Views/widgets/msg_toast.dart';
// import 'package:edurise/Views/widgets/msg_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';

// import 'package:geocoder/geocoder.dart';

class SearchTuitionPage extends StatefulWidget {
  @override
  _SearchTuitionPageState createState() => _SearchTuitionPageState();
}

class _SearchTuitionPageState extends State<SearchTuitionPage> {
  TextEditingController _pincodeController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool ispincodeselected = false;
  String? pincode_location = '';
  var longitude;
  var latitude;
  Map<String, String>? userLocation;
  bool isLoading = true;

  bool isLocationAccessGiven = false;

  Future<String?> _getLocation() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);

    longitude = position.longitude;
    latitude = position.latitude;

    String longi = longitude.toString().substring(0, 7);
    String lati = latitude.toString().substring(0, 7);

    userLocation = {lati: longi};

    List<Placemark> placemarks =
        await placemarkFromCoordinates(latitude, longitude);

    // print("longitude - $longitude");
    // print("latitude - $latitude");

    pincode_location = placemarks.first.postalCode;
    setState(() {
      isLocationAccessGiven = true;
      isLoading = false;
    });

    return pincode_location;
  }

  @override
  void initState() {
    super.initState();
    _getLocation();
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    var pin = 0;
    return isLoading
        ? LandingPage()
        : Scaffold(
            body: SingleChildScrollView(
              child: Container(
                color: CustomColors.secondaryColor,
                height: height,
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: <Widget>[
                      SizedBox(
                        height: height / 15,
                      ),
                      Row(
                        children: [
                          SizedBox(
                            width: width / 20,
                          ),
                          InkWell(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LandingPage()),
                              );
                            },
                            child: AnimatedContainer(
                              duration: Duration(seconds: 1),
                              width: height / 18,
                              height: height / 18,
                              child: Icon(
                                Icons.arrow_back,
                                color: CustomColors.buttonColor,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white70,
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Image.asset(
                        "assets/images/logo_transparent.png",
                        height: height / 4,
                        width: width / 2,
                      ),
                      SizedBox(
                        height: height / 50,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Text(
                          'Hey 👋 \nSearch Tuitions...',
                          style: TextStyle(
                            fontSize: height / 40,
                            color: CustomColors.textColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(
                        height: height / 20,
                      ),
                      !ispincodeselected
                          ? InkWell(
                              onTap: () => {
                                // print(pincode_location),

                                if (isLocationAccessGiven)
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => GuestDashBoard(
                                              pincode_location.toString(),
                                              userLocation!)))
                                else
                                  {
                                    msgToast(
                                        "Please give Access Location Permission"),
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                LandingPage()))
                                  }

                                // msgToast("Currently not available! try using pincode")
                              },
                              child: AnimatedContainer(
                                duration: Duration(seconds: 1),
                                width: width / 1.4,
                                height: height / 14,
                                alignment: Alignment.center,
                                child: Text(
                                  "By Your Location",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: height / 45,
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: CustomColors.buttonColor,
                                  borderRadius: BorderRadius.circular(15),
                                ),
                              ),
                            )
                          : SizedBox(),
                      !ispincodeselected
                          ? SizedBox(
                              height: height / 20,
                            )
                          : SizedBox(),
                      !ispincodeselected
                          ? InkWell(
                              onTap: () => {
                                setState(() {
                                  ispincodeselected = true;
                                })
                              },
                              child: AnimatedContainer(
                                duration: Duration(seconds: 1),
                                width: width / 1.4,
                                height: height / 14,
                                alignment: Alignment.center,
                                child: Text(
                                  "By Your Pincode",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: height / 45,
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  color: CustomColors.buttonColor,
                                  borderRadius: BorderRadius.circular(15),
                                ),
                              ),
                            )
                          : SizedBox(),
                      ispincodeselected
                          ? Padding(
                              padding: const EdgeInsets.only(
                                  left: 30, right: 30, bottom: 15),
                              child: TextFormField(
                                cursorColor: CustomColors.toyoPrimaryColor,
                                controller: _pincodeController,
                                autocorrect: true,
                                keyboardType: TextInputType.number,
                                style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14,
                                  color: CustomColors.toyoPrimaryColor,
                                ),
                                decoration: InputDecoration(
                                  hintText: "Ex: 313423",
                                  labelText: "Enter Your Pincode",
                                  filled: true,
                                  fillColor: CustomColors.secondaryColor,
                                  labelStyle: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      fontSize: 14,
                                      color: CustomColors.primaryColor),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                    borderSide: BorderSide(
                                      color: CustomColors.primaryColor,
                                      width: 2.0,
                                    ),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(30.0),
                                    borderSide: BorderSide(
                                      color: CustomColors.primaryColor,
                                      width: 2.0,
                                    ),
                                  ),
                                ),
                                validator: (value) {
                                  if (value!.length < 6) {
                                    return "Pincode not valid! Try Again!";
                                  }
                                  return null;
                                },
                              ),
                            )
                          : SizedBox(),
                      ispincodeselected
                          ? SizedBox(
                              height: height / 30,
                            )
                          : SizedBox(),
                      ispincodeselected
                          ? Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                InkWell(
                                  onTap: () => {
                                    setState(() {
                                      ispincodeselected = false;
                                    })
                                  },
                                  child: AnimatedContainer(
                                    duration: Duration(seconds: 1),
                                    width: width / 2.9,
                                    height: height / 17,
                                    alignment: Alignment.center,
                                    child: Text(
                                      "Cancel",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: height / 45,
                                      ),
                                    ),
                                    decoration: BoxDecoration(
                                      color: CustomColors.buttonColor,
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: width / 10,
                                ),
                                InkWell(
                                  onTap: () => {
                                    if (_formKey.currentState!.validate())
                                      {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    GuestDashBoard(
                                                        _pincodeController.text
                                                            .toString(),
                                                        userLocation!))),
                                      }
                                  },
                                  child: AnimatedContainer(
                                    duration: Duration(seconds: 1),
                                    width: width / 2.9,
                                    height: height / 17,
                                    alignment: Alignment.center,
                                    child: Text(
                                      "Submit",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: height / 45,
                                      ),
                                    ),
                                    decoration: BoxDecoration(
                                      color: CustomColors.buttonColor,
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                  ),
                                )
                              ],
                            )
                          : SizedBox(),
                    ],
                  ),
                ),
              ),
            ),
          );
  }
}
