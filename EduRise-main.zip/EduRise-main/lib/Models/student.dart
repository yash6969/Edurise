import 'dart:convert';

class Student {
  final String uid;
  final String studentName;
  final String mobileNumber;

  Student({
    required this.uid,
    required this.studentName,
    required this.mobileNumber,
  });

  Student copyWith({
    String? uid,
    String? studentName,
    String? mobileNumber,
  }) {
    return Student(
      uid: uid ?? this.uid,
      studentName: studentName ?? this.studentName,
      mobileNumber: mobileNumber ?? this.mobileNumber,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'studentName': studentName,
      'mobileNumber': mobileNumber,
    };
  }

  factory Student.fromMap(Map<String, dynamic> map) {
    return Student(
      uid: map['uid'],
      studentName: map['studentName'],
      mobileNumber: map['mobileNumber'],
    );
  }

  String toJson() => json.encode(toMap());

  factory Student.fromJson(String source) =>
      Student.fromMap(json.decode(source));

  @override
  String toString() =>
      'Student(uid: $uid, studentName: $studentName, mobileNumber: $mobileNumber)';

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is Student &&
        other.uid == uid &&
        other.studentName == studentName &&
        other.mobileNumber == mobileNumber;
  }

  @override
  int get hashCode =>
      uid.hashCode ^ studentName.hashCode ^ mobileNumber.hashCode;
}
