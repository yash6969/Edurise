import 'dart:convert';

class Faculty {
  final String uid;
  final String facultyName;
  final String qualification;

  Faculty(
    this.uid,
    this.facultyName,
    this.qualification,
  );

  Faculty copyWith({
    String? uid,
    String? facultyName,
    String? qualification,
  }) {
    return Faculty(
      uid ?? this.uid,
      facultyName ?? this.facultyName,
      qualification ?? this.qualification,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'facultyName': facultyName,
      'qualification': qualification,
    };
  }

  factory Faculty.fromMap(Map<String, dynamic> map) {
    return Faculty(
      map['uid'],
      map['facultyName'],
      map['qualification'],
    );
  }

  String toJson() => json.encode(toMap());

  factory Faculty.fromJson(String source) =>
      Faculty.fromMap(json.decode(source));

  @override
  String toString() =>
      'Faculty(uid: $uid, facultyName: $facultyName, qualification: $qualification)';

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is Faculty &&
        other.uid == uid &&
        other.facultyName == facultyName &&
        other.qualification == qualification;
  }

  @override
  int get hashCode =>
      uid.hashCode ^ facultyName.hashCode ^ qualification.hashCode;
}
