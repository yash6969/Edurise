import 'dart:convert';

import 'package:flutter/foundation.dart';

import 'package:edurise/Models/faculty.dart';

class Tuition {
  final String uid;
  final String tuitionName;
  final String mobileNumber;
  final String address;
  final String pincode;
  final String tuitionDescription;
  final String achievements;
  final int numberOfFaculties;
  final List<Faculty> faculty;
  final String subjects;
  final String classes;
  final String fee;
  final String modeOfTeaching;
  final String ownerName;
  final Map<String, String>? reviews;
  final int? reach;
  final int? views;
  final Map<String, String>? usersLocations;
  final Map<String, String>? tuitionLocation;
  Tuition({
    required this.uid,
    required this.tuitionName,
    required this.mobileNumber,
    required this.address,
    required this.pincode,
    required this.tuitionDescription,
    required this.achievements,
    required this.numberOfFaculties,
    required this.faculty,
    required this.subjects,
    required this.classes,
    required this.fee,
    required this.modeOfTeaching,
    required this.ownerName,
    this.reviews,
    this.reach,
    this.views,
    this.usersLocations,
    this.tuitionLocation,
  });

  Tuition copyWith({
    String? uid,
    String? tuitionName,
    String? mobileNumber,
    String? address,
    String? pincode,
    String? tuitionDescription,
    String? achievements,
    int? numberOfFaculties,
    List<Faculty>? faculty,
    String? subjects,
    String? classes,
    String? fee,
    String? modeOfTeaching,
    String? ownerName,
    Map<String, String>? reviews,
    int? reach,
    int? views,
    Map<String, String>? usersLocations,
    Map<String, String>? tuitionLocation,
  }) {
    return Tuition(
      uid: uid ?? this.uid,
      tuitionName: tuitionName ?? this.tuitionName,
      mobileNumber: mobileNumber ?? this.mobileNumber,
      address: address ?? this.address,
      pincode: pincode ?? this.pincode,
      tuitionDescription: tuitionDescription ?? this.tuitionDescription,
      achievements: achievements ?? this.achievements,
      numberOfFaculties: numberOfFaculties ?? this.numberOfFaculties,
      faculty: faculty ?? this.faculty,
      subjects: subjects ?? this.subjects,
      classes: classes ?? this.classes,
      fee: fee ?? this.fee,
      modeOfTeaching: modeOfTeaching ?? this.modeOfTeaching,
      ownerName: ownerName ?? this.ownerName,
      reviews: reviews ?? this.reviews,
      reach: reach ?? this.reach,
      views: views ?? this.views,
      usersLocations: usersLocations ?? this.usersLocations,
      tuitionLocation: tuitionLocation ?? this.tuitionLocation,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'tuitionName': tuitionName,
      'mobileNumber': mobileNumber,
      'address': address,
      'pincode': pincode,
      'tuitionDescription': tuitionDescription,
      'achievements': achievements,
      'numberOfFaculties': numberOfFaculties,
      'faculty': faculty.map((x) => x.toMap()).toList(),
      'subjects': subjects,
      'classes': classes,
      'fee': fee,
      'modeOfTeaching': modeOfTeaching,
      'ownerName': ownerName,
      'reviews': reviews,
      'reach': reach,
      'views': views,
      'usersLocations': usersLocations,
      'tuitionLocation': tuitionLocation,
    };
  }

  factory Tuition.fromMap(Map<String, dynamic> map) {
    return Tuition(
      uid: map['uid'],
      tuitionName: map['tuitionName'],
      mobileNumber: map['mobileNumber'],
      address: map['address'],
      pincode: map['pincode'],
      tuitionDescription: map['tuitionDescription'],
      achievements: map['achievements'],
      numberOfFaculties: map['numberOfFaculties'],
      faculty:
          List<Faculty>.from(map['faculty']?.map((x) => Faculty.fromMap(x))),
      subjects: map['subjects'],
      classes: map['classes'],
      fee: map['fee'],
      modeOfTeaching: map['modeOfTeaching'],
      ownerName: map['ownerName'],
      reviews: map['reviews'] != null
          ? Map<String, String>.from(map['reviews'])
          : null,
      reach: map['reach'] != null ? map['reach'] : null,
      views: map['views'] != null ? map['views'] : null,
      usersLocations: map['usersLocations'] != null
          ? Map<String, String>.from(map['usersLocations'])
          : null,
      tuitionLocation: map['tuitionLocation'] != null
          ? Map<String, String>.from(map['tuitionLocation'])
          : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory Tuition.fromJson(String source) =>
      Tuition.fromMap(json.decode(source));

  @override
  String toString() {
    return 'Tuition(uid: $uid, tuitionName: $tuitionName, mobileNumber: $mobileNumber, address: $address, pincode: $pincode, tuitionDescription: $tuitionDescription, achievements: $achievements, numberOfFaculties: $numberOfFaculties, faculty: $faculty, subjects: $subjects, classes: $classes, fee: $fee, modeOfTeaching: $modeOfTeaching, ownerName: $ownerName, reviews: $reviews, reach: $reach, views: $views, usersLocations: $usersLocations, tuitionLocation: $tuitionLocation)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is Tuition &&
        other.uid == uid &&
        other.tuitionName == tuitionName &&
        other.mobileNumber == mobileNumber &&
        other.address == address &&
        other.pincode == pincode &&
        other.tuitionDescription == tuitionDescription &&
        other.achievements == achievements &&
        other.numberOfFaculties == numberOfFaculties &&
        listEquals(other.faculty, faculty) &&
        other.subjects == subjects &&
        other.classes == classes &&
        other.fee == fee &&
        other.modeOfTeaching == modeOfTeaching &&
        other.ownerName == ownerName &&
        mapEquals(other.reviews, reviews) &&
        other.reach == reach &&
        other.views == views &&
        mapEquals(other.usersLocations, usersLocations) &&
        mapEquals(other.tuitionLocation, tuitionLocation);
  }

  @override
  int get hashCode {
    return uid.hashCode ^
        tuitionName.hashCode ^
        mobileNumber.hashCode ^
        address.hashCode ^
        pincode.hashCode ^
        tuitionDescription.hashCode ^
        achievements.hashCode ^
        numberOfFaculties.hashCode ^
        faculty.hashCode ^
        subjects.hashCode ^
        classes.hashCode ^
        fee.hashCode ^
        modeOfTeaching.hashCode ^
        ownerName.hashCode ^
        reviews.hashCode ^
        reach.hashCode ^
        views.hashCode ^
        usersLocations.hashCode ^
        tuitionLocation.hashCode;
  }
}
